#========================================================================#
#   Project Name        : Third Party Datalake                           #
#   Team                : Team Cognizant                                 #
#   Date                : 04/24/2021                                     #
#   Framework component : Lambda function                                #
#   Description         : Function to validate valid data and control    #
#                         pair from landing area and generate spark      # 
#                         submit statements.                             #
#   Version             : 0.1(Initial version)                           #
#                                                                        #
#========================================================================#

import json
import boto3
import logging
import csv
import botocore
from datetime import datetime 
import sys
import csv 
import time 
import re 


# setting logging level
logger = logging.getLogger()
logger.setLevel(logging.INFO) 

s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')


def get_current_timestamp():
    """ Returns current timestamp """
    current_timestamp = datetime.now().strftime('%Y-%m-%d_%H:%M:%S') 
    return current_timestamp 

def read_input_config(bucket, key):
    """ Reads json config file from S3 """
    
    logger.info('Reading {} file'.format(key.split('/')[-1])) 
    response = s3_client.get_object(Bucket=bucket, Key=key)
    file_content = response['Body'].read().decode('utf-8')
    json_content = json.loads(file_content)
    return json_content

    
def get_s3_file_list(bucket, prefix):
    """ Returns list of files for input bucket and prefix """ 
    my_bucket = s3_resource.Bucket(bucket)
    s3_file_list =[]
    for my_bucket_object in my_bucket.objects.filter(Prefix=prefix):
        if my_bucket_object.key.split('/')[-1]!= '':
            s3_file_list.append(my_bucket_object.key.split('/')[-1]) 
    return s3_file_list

def file_pair_validator(job_limit,data_file_prefix,s3_file_list,subject_area,landing_bucket,source, validation_columns,error_config_dict):
    """
    Validates data and control file pair for a job
    :Returns valid pair dictionary for valid pair files
    :Returns invalid files dictionary (files having no valid data and control file pair)
    :Returns error message dictionary for files not having valida pair
    """
    logger.info('Data and control file pair validation started') 
    
    valid_pair_dict = {}
    invalid_pair_dict = {}
    error_desc_dict = {} 
    valid_file_list = []
    
    # create unique id for each job
    job_id = 'JOB_{}_{}'.format(data_file_prefix,datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    if len(s3_file_list) == 0:
        data_file_path = 'landing/data/{}/{}/{}'.format(source,subject_area,data_file_prefix)   
        invalid_pair_dict[job_id] = data_file_path
        valid_pair_dict[job_id] = valid_file_list 
        error_desc_dict[job_id] = get_error_message(error_config_dict,5) 
    
    # conditions check if only data files are present.  
    ctrl_file_count = 0
    for file in s3_file_list:
        if file.endswith('ctrl'):
            ctrl_file_count +=1
    
    if len(s3_file_list) > 0 and ctrl_file_count == 0:
        data_file_path = 'landing/data/{}/{}/{}'.format(source,subject_area,data_file_prefix)   
        invalid_pair_dict[job_id] = data_file_path
        valid_pair_dict[job_id] = list() 
        error_desc_dict[job_id] = get_error_message(error_config_dict,4)            

    # different scenario validation for data and control file pair availability in landing area
    for file in s3_file_list:
        if file.endswith('ctrl') :
            folder_prefix = re.split(r'(-?\d*\.?\d+)', data_file_prefix)[0] 
            folder_prefix = folder_prefix.replace('_','-')           
            landing_file_prefix = re.split(r'(-?\d*\.?\d+)', file)[0].strip('_')
            
            
            logger.info('folder_prefix :{}, landing_file_prefix :{}'.format(folder_prefix,landing_file_prefix)) 
            if folder_prefix in landing_file_prefix :    
            
                control_file_prefix = 'landing/data/{}/{}'.format(subject_area,file)   
                print("control_file_prefix :{}".format(control_file_prefix))   
                if file_exists(landing_bucket, control_file_prefix):
                    control_file_content = read_control_file(landing_bucket, control_file_prefix)
                    logger.info('control_file_content :{}'.format(control_file_content))
                    
                    data_file_name = None 
                    if validate_control_file(control_file_content, validation_columns): 
                        logger.info('data_file_name :{}'.format(data_file_name))
                        data_file_name = control_file_content[1].split(',')[0]
                        logger.info('data_file_name :{}'.format(data_file_name))
                        control_file_content = None 
                        
                        if data_file_name in s3_file_list:  
                            if data_file_name.split('dat')[0] == file.split('ctrl')[0]  and data_file_name in s3_file_list: 
                                valid_file_list.append(data_file_name)
                            else:
                                data_file_path = 'landing/data/{}/{}/{}/{}'.format(source,subject_area,data_file_prefix,data_file_name)
                                invalid_pair_dict[job_id] = data_file_path
                                error_desc_dict[job_id] = get_error_message(error_config_dict,9)
                        else:
                            data_file_path = 'landing/data/{}/{}/{}/{}'.format(source,subject_area,data_file_prefix,data_file_name)
                            invalid_pair_dict[job_id] = data_file_path
                            error_desc_dict[job_id] = get_error_message(error_config_dict,9)
                    else:
                        data_file_path = 'landing/data/{}/{}/{}/{}'.format(source,subject_area,data_file_prefix,data_file_name)
                        invalid_pair_dict[job_id] = data_file_path
                        error_desc_dict[job_id] = get_error_message(error_config_dict,8) 
            else:
                data_file_path = 'landing/data/{}/{}/{}'.format(source,subject_area,data_file_prefix) 
                invalid_pair_dict[job_id] = data_file_path
                error_desc_dict[job_id] = get_error_message(error_config_dict,10)       
    
    if len(valid_file_list) > job_limit:
        valid_pair_dict[job_id] = valid_file_list[0:job_limit]
    else:
        valid_pair_dict[job_id] = valid_file_list           
    return valid_pair_dict, invalid_pair_dict, error_desc_dict                   

def default_spark_job_args_generator(custom_spark_submit_flag, job_type=None):
    """ Generates spark job submit default arguments """       
    
    default_args_list = ["spark-submit","--class","org.apache.spark.examples.SparkPi","--master","yarn","--deploy-mode",\
                        "cluster"] 
    custom_param_list = ["--num-executors","","--executor-memory","","--executor-cores","","--driver-memory",""]

    if custom_spark_submit_flag and job_type == 'main_job':
        custom_param_list[1] = executer_numbers
        custom_param_list[3] = executor_memory 
        custom_param_list[5] = executor_cores
        custom_param_list[7] = driver_memory 
        default_args_list.extend(custom_param_list)     
    
    return default_args_list   

def get_step_audit_field():
    """ Returns step audit fields with default value """  
    step_audit_dict = {}
    step_audit_fields = ['JobId','JobKey','JobStepId','JobStepDesc','ProcessDate','StepStartTime','StepEndTime' \
                          'StepStatus','ErrorMessageId']
                          
    for field in step_audit_fields:
        step_audit_dict[field] =''
     
    step_audit_dict['ProcessDate'] = datetime.now().strftime('%Y-%m-%d')
    return step_audit_dict    

def create_step_audit_csv_file(audit_file, json_content):
    """" Creates csv file from dictionary in memory  """ 
    with open(audit_file, 'w') as file:
        csv_file = csv.writer(file)
        csv_file.writerow(["JobId","JobKey","JobStepId","JobStepDesc","ProcessDate","StepStartTime","StepEndTime","StepStatus","ErrorMessageId"])
        for item in json_content:
            csv_file.writerow([item.get('JobId'),item.get('JobKey'),item.get('JobStepId'),item.get('JobStepDesc'),item.get('ProcessDate'), \
                            item.get('StepStartTime'),item.get('StepEndTime'),item.get('StepStatus'),item.get('ErrorMessageId'),])
                            
    csv_binary = open(audit_file, 'rb').read()
    return csv_binary

def create_audit_csv_file(audit_file, json_content):
    """ Creates csv file for job audit in memory """ 
    with open(audit_file, 'w') as file:
        csv_file = csv.writer(file)
        csv_file.writerow(["JobId","JobKey","ProcessDate","JobStage","SubjectArea","FileName","SourceRowCount","SuccessRowCount",
                            "RejectedRowCount","JobStartTime","JobEndTime","JobStatus"]) 
        for item in json_content:
            csv_file.writerow([item.get('JobId'),item.get('JobKey'),item.get('ProcessDate'),item.get('JobStage'),item.get('SubjectArea'), \
                            item.get('FileName'),item.get('SourceRowCount'),item.get('SuccessRowCount'),item.get('RejectedRowCount'),item.get('JobStartTime'),\
                            item.get('JobEndTime'),item.get('JobStatus')]) 
                            
    csv_binary = open(audit_file, 'rb').read()
    return csv_binary

def write_audit(bucket, key, csv_binary,KMS_KEY):
    """ Writes audit to s3 bucket """
    try:
        obj = s3_resource.Object(bucket, key)
        obj.put(Body= csv_binary,ServerSideEncryption='aws:kms',SSEKMSKeyId=KMS_KEY) 
    except Exception as e :
        logger.info('some other error occured while writing audit :{}'.format(e))
 
def get_default_lambda_response(environment,subject_area,subject=None,message=None,code=2,concurrency_limit=0):   
    """
    Generated lambda response with default values
    """
    lambda_response = dict()
    lambda_response['code'] = code 
    lambda_response['ConcurrencyLimit'] = concurrency_limit 
    lambda_response['Jobs'] = []
    lambda_response['subject'] = subject
    lambda_response['message'] = message
    lambda_response['exception_subject'] = '{} -{} :Step function execution failed'.format(environment,subject_area)
    lambda_response['exception_message'] = 'Some service or spark submit exception occured in step function'
    lambda_response['cluster_failure_subject'] = '{} -{} :EMR cluster failed to launch'.format(environment,subject_area)
    lambda_response['cluster_failure_message'] = 'Some exception occured or expected value not provided in EMR cluster '
    
    return lambda_response
 
def get_bucket_mapping(path_config_json): 
    """
    Returns all bucket names used in the framework
    """
    bucket_dict = {}
    buckets = path_config_json['BucketName']
    bucket_dict['inbound_bucket'] = buckets['InboundBucket']
    bucket_dict['internal_bucket'] = buckets['InternalBucket']
    bucket_dict['confidential_bucket'] = buckets['ConfidentialBucket']    
    bucket_dict['internal_process_bucket'] = buckets['InternalProcesBucket']  
    bucket_dict['confidential_process_bucket'] = buckets['ConfidentialProcesBucket']  
    bucket_dict['code_bucket'] = buckets['CodeBucket']
    bucket_dict['log_bucket'] = buckets['LogsBucket']   
    
    return bucket_dict
 
def get_s3_prefix_mapping(path_config_json,input_file_type): 
    """ Returns prefix dictionary used in various bucket """
    
    s3_prefixes_dict = {}
    if input_file_type=="JSON":
        s3_prefixes_dict['data_processing_script'] = path_config_json['TPDLAdHocDataProcessingScript']
    elif input_file_type=="FLEX_XML":
        s3_prefixes_dict['data_processing_script'] = path_config_json['FLEXTPDLDataProcessingScript'] #new tpdl sources spark code added
    else:
        s3_prefixes_dict['data_processing_script'] = path_config_json['DataProcessingScript']
    s3_prefixes_dict['audit_merge_script'] = path_config_json['AuditMergeScript']
    
    prefixes = path_config_json['PrefixDetails']
    s3_prefixes_dict['landing_data_prefix'] = prefixes['LandingPrefix']['DataPrefix']
    s3_prefixes_dict['process_data_prefix'] = prefixes['ProcessPrefix']['DataPrefix']
    s3_prefixes_dict['process_audit_prefix'] = prefixes['ProcessPrefix']['AuditPrefix']
    s3_prefixes_dict['process_error_prefix'] = prefixes['ProcessPrefix']['ErrorPrefix']
    s3_prefixes_dict['process_archive_prefix'] = prefixes['ProcessPrefix']['ArchivePrefix']
    s3_prefixes_dict['process_temp_prefix'] = prefixes['ProcessPrefix']['TempPrefix']
    s3_prefixes_dict['datalake_data_prefix'] = prefixes['DatalakePrefix']['DataPrefix']
    s3_prefixes_dict['main_scripts_prefix'] = prefixes['CodePrefix']['MainScriptPrefix']
    s3_prefixes_dict['audit_merge_prefix'] = prefixes['CodePrefix']['AuditMergePrefix']
    
    s3_prefixes_dict['ddl_scripts_prefix'] = prefixes['CodePrefix']['DDLScriptPrefix']
    s3_prefixes_dict['ddl_scripts_prefix'] = prefixes['ConfigPrefix']['DePrefix']
    s3_prefixes_dict['schema_prefix'] = prefixes['ConfigPrefix']['SchemaPrefix']
    s3_prefixes_dict['schema_archive_prefix'] = prefixes['ConfigPrefix']['SchemaArchivePrefix']
    s3_prefixes_dict['ddl_prefix'] = prefixes['ConfigPrefix']['DDLPrefix'] 
    s3_prefixes_dict['log_emr_prefix'] = prefixes['LogsPrefix']['EmrPrefix']
    s3_prefixes_dict['log_de_prefix'] = prefixes['LogsPrefix']['DePrefix']
    
    return s3_prefixes_dict

def file_exists(bucket,key):
    """ Returns true if a file exists in s3 """
    flag =True
    try:
        s3_resource.Object(bucket,key).load()
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            # The object does not exist.
            flag = False
        else:
            # Something else has gone wrong.
            flag = False
    else:
        # The object does exist.
        flag = True
    return flag

def get_job_audit_fields(subject_area,job_start_time):
    """ Returns job audit fields with default values """
    job_audit = {}
    job_audit_fields =['JobId','JobKey','ProcessDate','JobStage','SubjectArea','FileName','SourceRowCount',\
                        'SuccessRowCount','RejectedRowCount','JobStartTime','JobEndTime','JobStatus']  
    for field in job_audit_fields:
        job_audit[field] = '' 
    process_date = datetime.now().strftime('%Y-%m-%d')
    job_audit['ProcessDate'] = process_date  
    job_audit['JobStage'] = 'Lambda'
    job_audit['SubjectArea'] = subject_area
    job_audit['SourceRowCount'] = 'NA'
    job_audit['SuccessRowCount'] = 'NA'
    job_audit['RejectedRowCount'] = 'NA'
    job_audit['JobStartTime'] = job_start_time
    
    return job_audit

def generate_step_audit_record(job_id,event_id,job_step,step_desc,step_start_time,step_end_time,step_status,error_message=''): 
    """
    Geneartes step audit records with the parameters provided 
    """
    step_audit_record = get_step_audit_field()
    step_audit_record['JobId'] = job_id   
    step_audit_record['JobKey'] = event_id  
    step_audit_record['JobStepId'] = job_step
    step_audit_record['JobStepDesc'] = step_desc
    step_audit_record['StepStartTime'] = step_start_time
    step_audit_record['StepEndTime'] = step_end_time
    step_audit_record['StepStatus'] = step_status
    step_audit_record['ErrorMessageId'] = error_message 
    return step_audit_record 
    
def additional_spark_args_generator(landing_prefix_dict,file_dict,data_processing_script_path,environment, event_id, config_bucket, config_prefix,conf_proc_bucket, source, subject_area,temp_file_size_limit,\
                                    step_audit_data,spark_job_list, valid_file_pair_path_dict,valid_file_pair_kms_dict ,sns_topic_arn,job_prefix_dict,process_timestamp,hdfs_path): 
    
    """ Generate job specific additional spark args apart from default ones """

    for job in file_dict.keys(): 
        
        if len(file_dict[job]) >0:
            spark_args_list = default_spark_job_args_generator(custom_spark_submit_flag,'main_job')   
            spark_args_list.append(data_processing_script_path)
            spark_args_list.append(environment)
            spark_args_list.append(job.replace('-','_'))    
            spark_args_list.append('JOB_{}'.format(job_prefix_dict[job].replace('-','_')))
            spark_args_list.append('{}_{}'.format(event_id, job_prefix_dict[job].replace('-','_')) )    
            spark_args_list.append(config_bucket)
            spark_args_list.append(config_prefix)
            spark_args_list.append(conf_proc_bucket)
            spark_args_list.append(source)
            spark_args_list.append(subject_area)
            spark_args_list.append(temp_file_size_limit)
            spark_args_list.append(landing_prefix_dict[job]) 
            spark_args_list.append(hdfs_path)  
            spark_args_list.append(json.dumps(file_dict[job]))  
            spark_args_list.append(valid_file_pair_kms_dict[job]) 
            spark_args_list.append(valid_file_pair_path_dict[job]) 
            spark_args_list.append(sns_topic_arn)
            
            time.sleep(1)     
            process_timestamp_milliseconds = datetime.now().strftime('%f')
            audit_file_timestamp = '{}_{}'.format(process_timestamp, process_timestamp_milliseconds) 
            spark_args_list.append(audit_file_timestamp)  
        
            spark_job_list.append(spark_args_list) 
    return spark_job_list 
    
def spark_complete_job_args_generator(spark_job_list):
    """
    Returns dictionary of spark job submit args for all valid files 
    """
    Jobs =[]
    spark_job_inputs = []
    for i in spark_job_list:
        sparkInputs =[]
        job_dict = {}
        for index, val in enumerate(i):
            d ={}
            d['Args{}'.format(index)] = val
            sparkInputs.append(d)
            job_dict['sparkInputs'] = sparkInputs   
            job_dict['ClusterId'] = "j-1VF1Z76DLS9EJ"
        Jobs.append(job_dict)  
    return Jobs
    
def additional_paths_args_generator(s3_prefixes_dict,source, subject_area, file_name_prefix):
    """
    Adds s3 paths to existing spark job arguments
    """
    logger.info('Adding addition s3 path as dictionary for spark')
    year="process_date_year={}".format(str(datetime.now().year))
    month="process_date_month={}".format(str(datetime.now().month).zfill(2)) 

    s3_path_dict = {}
    s3_path_dict['Schema_Dir_Path'] = s3_prefixes_dict['schema_prefix']    
    s3_path_dict['Schema_Dir_Path_FOR_DDL'] = s3_path_dict['Schema_Dir_Path']     # same path repetition
    s3_path_dict['Schema_Arc_Dir_Path'] = '{}/{}'.format(s3_prefixes_dict['schema_archive_prefix'],subject_area)
    s3_path_dict['DDL_Dir_Path'] = '{}/{}'.format(s3_prefixes_dict['ddl_prefix'],subject_area)
    s3_path_dict['Process_Data_Dir_Path'] = '{}/{}/{}/{}'.format(s3_prefixes_dict['process_data_prefix'],subject_area,year,month)  
    s3_path_dict['Process_Temp_ABC_Dir_Path'] = "{}/abc".format(s3_prefixes_dict['process_temp_prefix'])
    s3_path_dict['Process_Temp_Err_Dir_Path'] = "datalake/temp/error/{}/".format(subject_area)    
    s3_path_dict['Process_ABC_Dir_Path'] = "{}".format(s3_prefixes_dict['process_audit_prefix'])
    s3_path_dict['Process_Err_Dir_Path'] = "{}/{}/{}/{}".format(s3_prefixes_dict['process_error_prefix'],subject_area,year,month)
    s3_path_dict['Process_Arc_Dir_Path'] = "{}/{}/{}/{}".format(s3_prefixes_dict['process_archive_prefix'],subject_area,year,month) 
    s3_path_dict['Datalake_Data_Dir_Path'] = "{}/{}".format(s3_prefixes_dict['datalake_data_prefix'],subject_area)
    s3_path_dict['Logs_EMR_Dir_Path'] = s3_prefixes_dict['log_emr_prefix']
    s3_path_dict['Logs_DE_Dir_Path'] = "{}/{}/".format(s3_prefixes_dict['log_de_prefix'],subject_area)    
    
    return s3_path_dict  

def get_cluster_status(cluster_name):
    """
    Returns true if cluster is already active 
    """
    is_cluster_active = False
    emr_client=boto3.client('emr',region_name='us-east-2') 
    response = emr_client.list_clusters(ClusterStates=[
        'RUNNING','STARTING','WAITING','BOOTSTRAPPING'])  

    for i in range(len(response['Clusters'])):
        active_cluster = response['Clusters'][i]['Name']
        if active_cluster == cluster_name:
            is_cluster_active = True
    return is_cluster_active
    
def generate_audit(subject_area,event_id,file_dict,job_prefix_dict,job_start_time):        
    """ Generate job audit """
    job_audit_data = []
    for job_id in file_dict.keys():
        job_audit = get_job_audit_fields(subject_area,job_start_time) 
        job_audit['JobId'] = job_id 
        job_audit['JobKey'] = '{}_{}'.format(event_id,job_prefix_dict[job_id])

        if len(file_dict[job_id]) > 0:
            job_audit['JobStatus'] = 'Success'    
            job_audit['FileName'] = file_dict[job_id]
        else:
            job_audit['JobStatus'] = 'Failed'    
            job_audit['FileName'] = []

        job_audit['JobEndTime'] = get_current_timestamp() 
        job_audit_data.append(job_audit)          
    return job_audit_data 

def write_audit_to_s3(subject_area,audit_data,KMS_KEY,log_bucket,audit, process_timestamp):  
    """writes audit/step audit to s3 bucket""" 
    logger.info('writing job {} to s3'.format(audit)) 
    file_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    if audit == 'job_audit': 
        file = 'Lambda_{}_Main_Audit_{}.csv'.format(subject_area,process_timestamp) 
        audit_file = '/{}/{}'.format('tmp',file)  
        key = 'de/{}/{}'.format(subject_area,file)  
        csv_binary = create_audit_csv_file(audit_file, audit_data)  
    else:
        file = 'Lambda_{}_Step_Audit_{}.csv'.format(subject_area,process_timestamp)   
        audit_file = '/{}/{}'.format('tmp',file)
        key = 'de/{}/{}'.format(subject_area,file)     
        csv_binary = create_step_audit_csv_file(audit_file, audit_data)   
    write_audit(log_bucket,key,csv_binary,KMS_KEY) 
    
def kms_keys_mapping(path_config_json): 
    """ Returns kms keys mapping at different s3 prefix level """
    kms_key_dict = {}
    kms_keys = path_config_json['KMSKeys']
    for key in kms_keys.keys():
        kms_key_dict[key] = kms_keys[key]
    return kms_key_dict  

def read_control_file(bucket, key):
    """Reads csv control file """
    
    file = '{}/{}'.format(bucket,key)
    response = s3_client.get_object(Bucket=bucket, Key=key)
    file_content = response['Body'].read().decode('utf-8').splitlines()   
    logger.info('control file content :{}'.format(file_content))
    return file_content  

def get_error_message(error_config_dict, id):
    """Return error message for corresponding to id from parameters"""
    return error_config_dict[id]['MsgDescription'] 
    
def generate_audit_merge_params(audit_merge_script_location, subject_area, process_timestamp, landing_bucket, log_bucket,audit_kms_key,abc_kms_key ):
    """Generates args for audit merge script """
    
    audit_jobs = []
    audit_args_list = default_spark_job_args_generator(custom_spark_submit_flag,None)  
    audit_args_list.append(audit_merge_script_location) 
    audit_args_list.append(subject_area)
    audit_args_list.append(process_timestamp)
    audit_args_list.append(landing_bucket)
    audit_args_list.append(log_bucket)
    audit_args_list.append(audit_kms_key)
    audit_args_list.append(abc_kms_key)
    
    audit_jobs.append(audit_args_list) 
    return audit_jobs 
    
def validate_control_file(file_content, validation_columns): 
    """ Returns true if control file is valid """
    
    validation_fields = validation_columns['Fields'] 
    flag = True 
    if len(file_content) <=1:
        flag = False  
        return flag
    control_file_header = file_content[0]
    control_file_data = file_content[1]
    control_file_data_list = control_file_data.split(',')

    if validation_fields != control_file_header.split(',') or len(control_file_data_list) != len(validation_fields):   
        flag = False 
    return flag 

def send_sns_notification(sns_topic_arn, subject, message):
    """ Send SNS notification to stakeholders """
    client = boto3.client('sns',region_name='us-east-2')
    response = client.publish(
        TargetArn=sns_topic_arn,
        Message= message,
        Subject= subject,
        MessageStructure='string'
    )     
    
def check_key(input_dict,key):
    """ Checks if a key exists in """
    if key in input_dict:
        return True
    else:
        return False
       

def lambda_handler(event, context):
    try:
        # Get variables from cloudwatch event
        logger.info('Inputs from cloudwatch event : {}'.format(event))   
      
        config_bucket = event['Input']['config_bucket']    
        config_prefix = event['Input']['config_prefix'] 
        conf_proc_bucket = event['Input']['conf_proc_bucket']
        subject_area = event['Input']['subject_area']
        temp_file_size_limit=event['Input']['temp_file_size_limit']
        sns_topic_arn = event['Input']['TopicArn']
        cluster_name = event["Input"]["Name"]
        environment = event["Input"]["environment"].upper()
        if "file_type" in event["Input"].keys():
            input_file_type=event["Input"]["file_type"]
        else:
            input_file_type="XML"

        history_load_flag = False 
        if check_key(event['Input'],'history_flag'):
            history_load_flag = True 
            history_schedule = event["Input"]["history_schedule"]
        
        # spark submit custom parameters 
        global custom_spark_submit_flag,executer_numbers,executor_memory,executor_cores,driver_memory   
        custom_spark_submit_flag = False 
        if check_key(event['Input'],'custom_spark_submit_flag'):
            custom_spark_submit_flag = event["Input"]["custom_spark_submit_flag"]
            logger.info('custom_spark_submit_flag :{}'.format(custom_spark_submit_flag))     
            if custom_spark_submit_flag:
                executer_numbers = event["Input"]["executer_numbers"]
                executor_memory = event["Input"]["executor_memory"]
                executor_cores = event["Input"]["executor_cores"]    
                driver_memory = event["Input"]["driver_memory"]
            
        logger.info('cluster name :{}'.format(cluster_name)) 
        is_cluster_active = get_cluster_status(cluster_name)    
        is_cluster_active = False 
    
        if is_cluster_active:
            logger.info('Cluster already running, exiting from lambda')
            subject = "{}: {}- Another TPDL job is aleardy running".format(environment, subject_area)  
            message = "Summary: Another TPDL job is running on Cluster, exiting from lambda to avoid concurrency"  
            code = 6
            lambda_response = get_default_lambda_response(environment,subject_area,subject,message,code)  
            logger.info('lambda response :{}'.format(lambda_response)) 
            return lambda_response 
        else:
            logger.info('{} :Cluster is currently not active , proceeding with validation'.format(subject_area)) 
        
            logger.info('Setting constants value')
            PATH_CONFIG = 'BasePathMapConfig{}.json'.format(environment)    
            SCHEDULE_CONFIG = 'JobScheduleConfig.json'
            JOB_MAP_CONFIG = 'JobMapConfig.json'
            ERROR_CONFIG = 'ErrorMessageConfig.json'
            CONTROL_FILE_CONFIG = 'ControlFileFields.json'  
            
            event_id = context.aws_request_id
            logger.info('AWS request id :{}'.format(event_id)) 
            
            # Setting some global variables values 
            job_start_time = get_current_timestamp() 
            file_group_flag ='N' 
            job_process_date = datetime.now().strftime('%Y-%m-%d') 
            step_audit_data =[]
            job_audit_data = []

            logger.info('Reading ErrorMessage config file')
            error_config_prefix = '{}/{}'.format(config_prefix,ERROR_CONFIG)
            logger.info('Error message config location :{}'.format(error_config_prefix)) 

            if file_exists(config_bucket, error_config_prefix):
                error_config_dict = read_input_config(config_bucket,error_config_prefix)
                logger.info('ErrorMessageConfig file available in s3') 
            else:
                logger.info('{} file does not exists,generating exception response from lambda'.format(error_config_prefix))  
                default_lambda_response = get_default_lambda_response(environment,subject_area)
                default_lambda_response['subject'] = "{}:{} -config file missing ".format(environment,subject_area,ERROR_CONFIG)     
                default_lambda_response['message'] = "Summary :{} file does not exists in s3".format(error_config_prefix)    
                return default_lambda_response 
            
            path_config_prefix = '{}/{}'.format(config_prefix,PATH_CONFIG)  
            logger.info('path config location :{}'.format(path_config_prefix)) 
            
            if file_exists(config_bucket, path_config_prefix):
                path_config_json = read_input_config(config_bucket,path_config_prefix)
                logger.info('{} file available in s3'.format(PATH_CONFIG))   
            else:
                logger.info('{}:{}, {} file does not exists,generating exception response from lambda'.format(environment, subject_area,path_config_prefix)) 
                default_lambda_response = get_default_lambda_response(environment,subject_area)
                default_lambda_response['subject'] = "{}: {} -config file missing ".format(environment, subject_area, PATH_CONFIG)  
                default_lambda_response['message'] = "Summary :{} file does not exists in s3 ".format(path_config_prefix)  
                return default_lambda_response 
            
            if check_key(event['Input'],'job_limit'):
                job_limit = event['Input']['job_limit']
            else:
                job_limit = path_config_json['JobLimit']    
            # return job_limit   
            logger.info('Getting columns for control file validation')    
            ctrl_config_path = '{}/{}'.format(config_prefix, CONTROL_FILE_CONFIG) 
            ctrl_validation_columns = read_input_config(config_bucket, ctrl_config_path) 
            
            logger.info('Getting buckets and prefixes mapping ') 
            bucket_dict = get_bucket_mapping(path_config_json) 
            logger.info(' bucket_dict : {}'.format(bucket_dict))
            s3_prefixes_dict = get_s3_prefix_mapping(path_config_json,input_file_type)
            logger.info(' s3_prefixes_dict : {}'.format(s3_prefixes_dict))
            kms_key_dict = kms_keys_mapping(path_config_json) 
            logger.info('kms keys mapping :{}'.format(kms_key_dict)) 
            
            log_bucket = bucket_dict['log_bucket'] 
            logger.info('log bucket :{}'.format(log_bucket)) 
    
            logger.info('Reading job schedule config file ')
            job_specific_prefix = config_prefix.replace('BasePath',subject_area)
            if history_load_flag == True:
                schedule_config_path = '{}/{}_{}'.format(job_specific_prefix,history_schedule.upper(),SCHEDULE_CONFIG)
            else:
                schedule_config_path = '{}/{}_{}'.format(job_specific_prefix,subject_area.upper(),SCHEDULE_CONFIG)
            
            logger.info('Job schedule config location :{}'.format(schedule_config_path))  
            step_start_time = get_current_timestamp() 
            job_list =[]
            jobs =[]
            concurrency_limit = 0
    
            source =''
            schedule_config_validity = True 
            if file_exists(config_bucket, schedule_config_path):    
                schedule_config_dict = read_input_config(config_bucket,schedule_config_path)
                file_group_flag = schedule_config_dict['IsFileGroupped']
                concurrency_limit = schedule_config_dict['ConcurrencyLimit']
                source = schedule_config_dict['Source'] 
                jobs = schedule_config_dict['Jobs']
                hdfs_path = schedule_config_dict['HdfsPath']  
                logger.info('{} :{} config file available in s3 '.format(subject_area,schedule_config_path.split('/')[-1]))   
            else:
                logger.info('Generating exception response from lambda') 
                default_lambda_response = get_default_lambda_response(environment,subject_area)
                default_lambda_response['subject'] = "{}: {} config file missing ".format(environment, subject_area)  
                default_lambda_response['message'] = "Summary :{} file does not exists".format(schedule_config_path)  
                return default_lambda_response 
        
            logger.info('Getting list of jobs from schedule config') 
            for job in jobs:
                job_list.append(job['JobId'])
            logger.info(' job list : {}'.format(job_list))
            
            total_jobs = len(job_list)
            logger.info(' total jobs in config file :{}'.format(total_jobs))
            
            logger.info('Initializing dictionaries for valid , invalid and other necessary details mapping ')
            valid_file_pair_dict = {} 
            invalid_file_pair_dict = {} 
            valid_file_pair_path_dict = {}
            valid_file_pair_kms_dict = {} 
            job_prefix_dict = {} 
            error_message_dict = {} 
            landing_prefix_dict = {}
            audit_kms_key = None 
            
            for job in job_list:
                logger.info('tables name :{}'.format(job))
                job_config_file = '{}_{}'.format(job, JOB_MAP_CONFIG) 
                job_config_path = '{}/{}'.format(job_specific_prefix,job_config_file)
                logger.info('job config path :{}'.format(job_config_path)) 
                job_config_dict = read_input_config(config_bucket, job_config_path) 
                job_steps = job_config_dict['JobStepConfig']
                
                #hdfs_path = bucket_confidentiality = job_config_dict['JobConfig']['HdfsPath']   
                
                job_start_time = get_current_timestamp()  
                logger.info('validating config file')
                job_audit_step  = 1 
                step_desc = 'Lambda: validate config files'
                step_start_time = get_current_timestamp()
   
                file_name_prefix = job_config_dict['JobConfig']['FileNamePrefix']    
                logger.info('FileNamePrefix :{}'.format(file_name_prefix))    
                bucket_confidentiality = job_config_dict['JobConfig']['Confidentiality'] 
                keys_dict = {}
                keys_dict['config_kms_key'] = kms_key_dict['ConfigKey']  
                keys_dict['logs_kms_key'] = kms_key_dict['LogsKey'] 
                
                landing_bucket = bucket_dict['inbound_bucket']   
                audit_kms_key = '' 
                abc_kms_key = ''   
    
                audit_kms_key = kms_key_dict['LogsKey']
                abc_kms_key = kms_key_dict['InternalProcessKey']
                keys_dict['process_kms_key'] = kms_key_dict['InternalProcessKey']
                keys_dict['confidential_process_key'] = kms_key_dict['ConfidentialProcessKey']   
                keys_dict['datalake_kms_key'] = kms_key_dict['InternalDatalakeKey']      

                logger.info('landing_bucket :{}'.format(landing_bucket)) 
                landing_prefix = 'landing/data/{}/'.format(subject_area)        
                logger.info('landing prefix  :{}'.format(landing_prefix))  
                s3_file_list = get_s3_file_list(landing_bucket, landing_prefix) 
                logger.info('s3_file_list  :{}'.format(s3_file_list)) 
                
                job_step = job_config_dict['JobStepConfig']
                
                if job_step[1]['Active'] == 'Y':
                    valid_pair_dict,invalid_pair_dict, error_desc_dict = file_pair_validator(job_limit,file_name_prefix, s3_file_list,subject_area,landing_bucket,source, ctrl_validation_columns ,error_config_dict)   
                
                    logger.info('Creating details mapping for valid pair of files ')
                    for job_id in valid_pair_dict.keys():
                        logger.info('Creating one to one mapping of jobs with their details ')
                        valid_file_pair_dict[job_id] = valid_pair_dict[job_id]   
                        landing_prefix_dict[job_id] = 's3://{}/landing/data/{}/'.format(landing_bucket,subject_area)              
                        job_prefix_dict[job_id] = file_name_prefix 
                        valid_file_pair_path_dict[job_id] = json.dumps(additional_paths_args_generator(s3_prefixes_dict,source, subject_area, file_name_prefix))
                        valid_file_pair_kms_dict[job_id] = json.dumps(keys_dict) 
                        
                    
                    logger.info('Creating details mapping for invalid pair of files')     
                    for job_id in invalid_pair_dict.keys(): 
                        job_prefix_dict[job_id] = file_name_prefix 
                        invalid_file_path = 's3://{}/landing/data/{}/{}/{}'.format(landing_bucket,source,subject_area,file_name_prefix)  
                        invalid_file_pair_dict[job_id] = invalid_file_path 
                        error_message_dict[job_id] = error_desc_dict[job_id] 
                    
                    if len(valid_pair_dict.keys()) == 0 and len(invalid_pair_dict.keys()) == 0 and len(s3_file_list)!= 0 : 
                        job_id = 'JOB_{}_{}'.format(file_name_prefix,datetime.now().strftime('%Y%m%d_%H%M%S_%f'))  
                        job_prefix_dict[job_id] = file_name_prefix 
                        invalid_file_path = 's3://{}/landing/data/{}/{}/{}'.format(landing_bucket,source,subject_area,file_name_prefix)  
                        invalid_file_pair_dict[job_id] = invalid_file_path
                        error_message_dict[job_id] = get_error_message(error_config_dict, 6)  
                
                # return  len(valid_pair_dict[job_id])         
                logger.info('valid file pair mapping :{}'.format(valid_file_pair_dict)) 
                logger.info('Invalid file pair mapping :{}'.format(invalid_file_pair_dict))  
                
            step_start_time = get_current_timestamp() 
            validation_audit_fields = get_step_audit_field()
            job_audit_step = 2
            step_desc = 'Data and control file pair validation'
            valid_pair_files = []  
            invalid_pair_file = [] 
            logger.info("generating step audit for data and control file pair validation step ")
            
            # return valid_file_pair_dict , invalid_file_pair_dict 
            
            for job_id in valid_file_pair_dict.keys():
                if len(valid_file_pair_dict[job_id]) > 0:  
                    job_key = '{}_{}'.format(event_id,job_prefix_dict[job_id]) 
                    step_end_time = get_current_timestamp()
                    step_status = 'Success'
                    step_audit_record = generate_step_audit_record(job_id,job_key,job_audit_step,step_desc,step_start_time,step_end_time,step_status)
                    step_audit_data.append(step_audit_record)
                    valid_pair_files.append(job_id)
                else:
                    job_key = '{}_{}'.format(event_id,job_prefix_dict[job_id])   
                    step_end_time = get_current_timestamp()
                    step_status = 'Failure'  
                    error_message = error_message_dict[job_id]
                    step_audit_record = generate_step_audit_record(job_id,job_key,job_audit_step,step_desc,step_start_time,step_end_time,step_status, error_message)
                    step_audit_data.append(step_audit_record)
                    invalid_pair_file.append(job_id) 
                    
            # return valid_file_pair_dict,invalid_file_pair_dict
                    
            logger.info('Jobs  having valid data and control file pair :{}'.format(list(valid_pair_files))) 
            logger.info('Jobs not having valid data and control file pair :{}'.format(list(invalid_pair_file)))  
    
            logger.info('Genearating lambda response after file pair validation') 
            data_processing_script_path = 's3://{}/{}/{}'.format(bucket_dict['code_bucket'],s3_prefixes_dict['main_scripts_prefix'],s3_prefixes_dict['data_processing_script'])
            audit_merge_script_path = 's3://{}/{}/{}'.format(bucket_dict['code_bucket'],s3_prefixes_dict['audit_merge_prefix'],s3_prefixes_dict['audit_merge_script'])
            
            # Code changes for clarabridge
            valid_file_list = []
            invalid_file_job_id = []
            valid_file_job_id = []
            for job_id in valid_file_pair_dict.keys():
                if len(valid_file_pair_dict[job_id]) > 0:
                    valid_file_list.extend(valid_file_pair_dict[job_id])
                    valid_file_job_id.append(job_id)  
                else:
                    invalid_file_job_id.append(job_id) 
                    
            # return invalid_file_job_id     
            
            print('complete Path :{}'.format(list(landing_prefix_dict.values())[0]))     
            #file_path = list(landing_prefix_dict.values())[0]
            # Thirdy party changes
            file_path = list(landing_prefix_dict.values())[0]
            # file_path_list = []
            for index, filename in enumerate(valid_file_list):   
                valid_file_list[index] = "{}{}".format(file_path,filename)             
            
            file_timestamp = datetime.now().strftime('%Y%m%d') 
            valid_file_string = "\n".join(valid_file_list) 
            print("valid_file_string :{}".format(valid_file_string))    
            # process_bucket = 'fi-edo-0760-tpdl-dev-process-internal'    
            process_bucket = bucket_dict['internal_process_bucket']
            process_key = 'file-list/{}/{}_filelist_{}.txt'.format(subject_area,subject_area, file_timestamp)         
            # process_kms_key = "arn:aws:kms:us-east-2:689759321266:key/2dbe6607-6349-40c5-a796-fd80844715e3" 
            process_kms_key = kms_key_dict['InternalProcessKey']
            s3_resource.Object(process_bucket, process_key).put(Body=valid_file_string,ServerSideEncryption='aws:kms',SSEKMSKeyId=process_kms_key)      
        
            
            # return valid_file_list , invalid_file_job_id           
            if len(valid_file_list) == 0: 
                logger.info('No jobs with valid file pair present ') 
                lambda_response = get_default_lambda_response(environment,subject_area)   
                lambda_response['code'] = 3 
                lambda_response['subject'] = "{} :{}-Data and control file pair not present for table".format(environment,subject_area )  
                lambda_response['message'] = "Summary: Valid file pair not present for job :{}".format(list(invalid_pair_file))
                process_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                   
                subject = lambda_response['subject']
                message = lambda_response['message']    
                
                logger.info('Writing main audit and step audit to s3 ')
                write_audit_to_s3(subject_area,step_audit_data,kms_key_dict['LogsKey'],log_bucket,'job_step_audit',process_timestamp) 
                if len(invalid_pair_file) > 0: 
                    job_audit_data.extend(generate_audit(subject_area,event_id,invalid_file_pair_dict,job_prefix_dict,job_start_time))    
                write_audit_to_s3(subject_area,job_audit_data,kms_key_dict['LogsKey'],log_bucket,'job_audit',process_timestamp)  
                send_sns_notification(sns_topic_arn, subject, message)                     
                return lambda_response 
            elif len(valid_file_list) > 0 and file_group_flag =='N':  
                step_start_time = get_current_timestamp()
                lambda_response = get_default_lambda_response(environment,subject_area)
                process_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S') 
                lambda_response['code'] = 1
                lambda_response['ConcurrencyLimit'] = concurrency_limit 
                lambda_response['subject'] = "{}:{} data and control files are present ".format(environment, subject_area)  
                lambda_response['message'] = "Summary :Proceeding spark job execution for valid file pairs present :{} ".format(list(valid_pair_files))
                print("event manipulation :{}".format(event["Input"]["TPDLMaster"]['FormattedInputsForEmr']['Args'][3]['Arg4'])) 
                key_field = event["Input"]["TPDLMaster"]['FormattedInputsForEmr']['Args'][3]['Arg4']
                file_timestamp = datetime.now().strftime('%Y%m%d')     
                event["Input"]["TPDLMaster"]['FormattedInputsForEmr']['Args'][3]['Arg4'] = "{}/{}_filelist_{}.txt".format(key_field,subject_area,file_timestamp)     
                lambda_response['FormattedInputsForEmr'] = event["Input"]["TPDLMaster"]['FormattedInputsForEmr'] 
                process_path_key = event["Input"]["TPDLMaster"]['FormattedInputsForEmr']['Args'][3]['Arg4']  
      
                   
                spark_job_list =[]    
                step_start_time = get_current_timestamp()    
                logger.info('data_processing_script_path :{}'.format(data_processing_script_path))
                
                spark_job_list = additional_spark_args_generator(landing_prefix_dict,valid_file_pair_dict,data_processing_script_path,environment, event_id, config_bucket, config_prefix,conf_proc_bucket, source, subject_area,temp_file_size_limit, step_audit_data,\
                                    spark_job_list, valid_file_pair_path_dict,valid_file_pair_kms_dict,sns_topic_arn,job_prefix_dict,process_timestamp,hdfs_path)   
                
                logger.info('Generating spark args for audit merge job ') 
                audit_args_list = generate_audit_merge_params(audit_merge_script_path, subject_area, process_timestamp ,bucket_dict['internal_bucket'], log_bucket,audit_kms_key, abc_kms_key )
                audit_merge_job = spark_complete_job_args_generator(audit_args_list) 
                
                lambda_response['audit_merge_job'] = audit_merge_job  
                logger.info('Spark args fot audit merge job generated ') 
  
                job_audit_step = 3
                step_desc = 'Spark job submit argument generation'  
                step_end_time = get_current_timestamp() 
                
                Jobs = spark_complete_job_args_generator(spark_job_list) 
                lambda_response['Jobs'] = Jobs
                if len(Jobs) > 0:
                    step_status = 'Success' 
                else:
                    step_status = 'Failed'
                    lambda_response = get_default_lambda_response(environment,subject_area,subject,message) 
                    logger.info('lambda response :{}'.format(lambda_response))
                    lambda_response['subject'] = "{}: {}-Spark jobs are not getting correctly populated".format(environment,subject_area)  
                    lambda_response['message'] = "Summary :Some error occured after valiadtion of files,not able to generate correct jobs in args"
                
                logger.info('Writing step sudit to s3 ')
                for job in valid_pair_files:   
                    job_key = '{}_{}'.format(event_id, job_prefix_dict[job])   
                    step_audit_record = generate_step_audit_record(job,job_key,job_audit_step,step_desc,step_start_time,step_end_time,step_status)  
                    step_audit_data.append(step_audit_record) 
                    write_audit_to_s3(subject_area,step_audit_data,kms_key_dict['LogsKey'],log_bucket,'job_step_audit',process_timestamp) 
                
                logger.info('Writing main audit to s3 ')
                job_end_time = get_current_timestamp()    
                if len(valid_pair_files) > 0: 
                    job_audit_data.extend(generate_audit(subject_area,event_id,valid_file_pair_dict,job_prefix_dict,job_start_time)) 
                if len(invalid_file_job_id) > 0: 
                    #job_audit_data.extend(generate_audit(subject_area,event_id,invalid_file_pair_dict,job_prefix_dict,job_start_time))  
                    logger.info('Generating subject and message for invalid pair of files ')
                    subject = '{} : {} Lambda file validation '.format(environment,subject_area)   
                    message = "Summary : Jobs not having valid file pair :{} \n \nJobs having valid file pair :{} \n\n Proceeding spark job execution for valid pair of files".format(list(invalid_file_job_id),list(valid_file_job_id))       
                
                    send_sns_notification(sns_topic_arn, subject, message)                     
                write_audit_to_s3(subject_area,job_audit_data,kms_key_dict['LogsKey'],log_bucket,'job_audit',process_timestamp)
                return lambda_response         
            else:
                logger.info('Invalid condition found from lambda') 
                environment = event["Input"]["environment"].upper()
                logger.info('Generating Invalid condition response from lambda')  
                subject = "{}:{}-Invalid condition found in lambda ".format(environment,subject_area)
                message = "Summary :No matching condition found for situation " 
                lambda_response = get_default_lambda_response(environment,subject_area,subject,message) 
                logger.info('lambda response :{}'.format(lambda_response)) 
                return lambda_response 
                
        
    except Exception as e:
        logger.info('Exception occured : {}, on line :{}'.format(e,sys.exc_info()[-1].tb_lineno)) 
        logger.info('Generating exception response from lambda') 
        environment = event["Input"]["environment"].upper()
        subject_area = event["Input"]["subject_area"].upper()
        subject = "{}: Lambda validation failed for group {}".format(environment, subject_area) 
        message = "Error detail: Exception occured in file validation :{} on line {} ".format(e,sys.exc_info()[-1].tb_lineno) 
        lambda_response = get_default_lambda_response(environment,subject_area,subject,message) 
        logger.info('lambda response :{}'.format(lambda_response)) 
        return lambda_response 