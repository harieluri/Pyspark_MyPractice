#========================================================================#
#   Project Name        : Third Party Datalake                           #
#   Team                : Cognizant Team                                 #
#   Date started        : 04/20/2021                                     #
#   Description         : Pyspark script to process xml data             #
#                         and loading into Athena by applying            #
#                         business rules.                                #
#   Version             : 0.6(Revised version)                           #
#========================================================================#

# Libraries and Packages import
import boto3
import json
from datetime import datetime
from datetime import date
import sys
from pyspark.sql.session import SparkSession
from pyspark.sql.utils import AnalysisException
from pyspark.sql import functions as f
from pyspark.sql.functions import lit,split,count,concat
from pyspark.sql.functions import to_timestamp
from types import FunctionType
from pyspark.sql.types import *
from pyspark.sql.functions import regexp_replace
import csv
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.functions import explode_outer,explode,col, substring,input_file_name,concat_ws
import tempfile
from io import StringIO
import traceback
import os
import time
import re
from urllib.parse import urlparse
from collections import defaultdict
import xmltodict
import pprint
from jsonflat import JsonFlat


# aws service instantians
s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')


def create_spark_session():
    global spark
    spark=SparkSession.builder.appName("Third Party Process").config("hive.metastore.connect.retries",5).\
          config("hive.metastore.client.factory.class","com.amazonaws.glue.catalog.metastore.AWSGlueDataCatalogHiveClientFactory").\
          config("spark.sql.parquet.writeLegacyFormat",True).\
          config("spark.sql.legacy.timeParserPolicy","CORRECTED").\
          config("spark.driver.maxResultSize","4g").\
          config("spark.rpc.message.maxSize",1024).\
          enableHiveSupport().getOrCreate()
          
    sc=spark.sparkContext
    sc._jsc.hadoopConfiguration().set("mapreduce.fileoutputcommitter.marksuccessfuljobs","false")
    sc._jsc.hadoopConfiguration().set("fs.s3.enableServerSideEncryption", "true")

    
def create_custom_log(log_level,function_name,message):
    """
    creating custom application logs
    """
    global str_datetime
    str_datetime=str(datetime.now())
    print("start time :",str_datetime)
    str_log_level=log_level
    str_func_name=function_name
    str_log_message=message
    str_final_log="{} {} {}: {}".format(str_datetime,str_log_level,str_func_name,str_log_message)
    print(str_final_log)
    
    
def prepare_jobstep_audit(step_id,step_desc,step_start_time, \
                                step_end_time,status,file_name='NA',error_message=None):
    """
    adding all job step details into public list
    """
    global lst_job_step_audit
    global file_process_date                                                
    file_process_date=str(datetime.strptime(process_date,'%Y%m%d_%H%M%S_%f').date())
    dict_job_step_audit={"JobId":job_id,"JobKey":job_key,"JobStepId":step_id,"JobStepDesc":step_desc,"FileName":file_name, \
                         "ProcessDate":file_process_date,"StepStartTime":step_start_time,"StepEndTime":step_end_time, \
                         "StepStatus": status,"ErrorMessage":error_message}
    
    lst_job_step_audit.append(dict_job_step_audit)
    
    
def write_jobstep_audit():
    """
    writing job step audit to S3
    """
    global dict_audit_col_detls
    global lst_job_step_audit
    try:
        create_custom_log("INFO",__name__,"Writing to Job Step Audit started.")
        field_names=dict_audit_col_detls.get("JobAuditStepFields")
        print('field_names : {}'.format(field_names))
        audit_s3 = boto3.client('s3')
        step_audit_file_name = 'Spark_'+sub_area +'_Step_Audit_'+process_date+'.csv'
        key_name=logs_de_dir_path+step_audit_file_name
        file_object = tempfile.NamedTemporaryFile()
        temp_filename=file_object.name
        with open(temp_filename, 'w') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=field_names)
            writer.writeheader()
            writer.writerows(lst_job_step_audit)
        
        audit_s3.upload_file(temp_filename,logbucket, key_name,ExtraArgs={'ServerSideEncryption':'aws:kms','SSEKMSKeyId':CNF_LOG_KMS_KEY})          
        lst_job_step_audit.clear()
        create_custom_log("INFO",__name__,"Writing to Job Step Audit completed.")
    except Exception as e:
        create_custom_log("ERROR",__name__,"Error in writing Job Step Audit.\nError:{}".format(str(e)))
    
    
def get_bucket_name(filepath):
    parse_obj=urlparse(filepath, allow_fragments=False)
    bucket=parse_obj.netloc
    path=parse_obj.path.lstrip("/")
    return bucket,path


def create_email_details(job_status,message):
    global email_subject,email_message
    file_name_prefix="LexisNexis-MVR"
    email_subject="{}-{} : SPARK JOB {}".format(environment,sub_area.upper(),job_status)    
    email_message="JOB ID: {}\n\nSUMMARY:\n{}".format(job_id,message)

    
def send_sns_notification():
    """
    """
    global email_subject,email_message    
    client = boto3.client('sns',region_name='us-east-2')       
    response = client.publish(
        TargetArn=sns_topic_arn,
        Message= email_message,
        Subject= email_subject,
        MessageStructure='string'
   )  


def write_job_audit_and_abc():
    """
    writing job step audit to S3
    """
    global dict_audit_col_detls
    global lst_job_audit
    try:
        create_custom_log("INFO",__name__,"Writing to Job Audit started.")
        field_names=dict_audit_col_detls.get("JobAuditFields")
        print('field_names : {}'.format(field_names))
        job_audit_file_name = 'Spark_'+sub_area +'_Main_Audit_'+process_date+'.csv'
        abc_key_val="{}/{}".format(abc_file_path,job_audit_file_name)
        audit_key_val=logs_de_dir_path+job_audit_file_name
        audit_s3 = boto3.client('s3')
        audit_file_name = 'Spark_'+sub_area +'_Main_Audit_'+process_date+'.csv'
        key_name = logs_de_dir_path + job_audit_file_name
        file_object = tempfile.NamedTemporaryFile()
        temp_filename=file_object.name
        with open(temp_filename, 'w') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=field_names)
            writer.writeheader()
            writer.writerows(lst_job_audit)
        abc_file_name =  "Spark_Main_Audit_{}.csv".format(process_date)
        abc_key_name = "abc/{}/{}".format(sub_area,abc_file_name)
        audit_s3.upload_file(temp_filename,logbucket, key_name,ExtraArgs={'ServerSideEncryption':'aws:kms','SSEKMSKeyId':CNF_LOG_KMS_KEY})            
        audit_s3.upload_file(temp_filename,internal_process_bucket, abc_key_name,ExtraArgs={'ServerSideEncryption':'aws:kms','SSEKMSKeyId':CNF_LOG_KMS_KEY})
        lst_job_audit.clear()
        create_custom_log("INFO",__name__,"Writing to Job Audit completed.")
    except Exception as e:
        create_custom_log("ERROR",__name__,"Error in writing Job Audit.\nError:{}".format(str(e)))
        
        
def prepare_job_audit(job_stage,job_status,data_file_rec_cnt,ctl_file_rec_cnt,dec_rec_count,dec_err_rec_count,spark_err_rec_count,valid_data_cnt,\
                        invalid_data_cnt,starttime,data_file):
    """
    ading all job step details into public list
    """
    global lst_job_audit
    endtime=datetime.now()
    file_process_date=str(datetime.strptime(process_date,'%Y%m%d_%H%M%S_%f').date())
    dict_job_audit={"Job_Id":job_id,"Job_Key":job_key,"Process_Date":file_process_date,"Job_Stage":job_stage,"Sub_Area":sub_area, \
                "File_Name":data_file,"Ctl_File_Record_Count":ctl_file_rec_cnt,"Data_File_Record_Count":data_file_rec_cnt, \
                "XML_File_Record_Count":dec_rec_count,"Decrypted_Error_Record_Count":dec_err_rec_count,"Spark_Error_Record_Count":spark_err_rec_count,\
                "Valid_Data_Count":valid_data_cnt,"Invalid_Data_Count":invalid_data_cnt,"Job_Status": job_status,"Start_Time":starttime,"End_Time":endtime}
    
    lst_job_audit.append(dict_job_audit)

    
def read_input_config(bucket,key):
    """
    Read config Files
    """
    json_content=None
    try:
        create_custom_log("INFO",__name__,"Reading files from bucket.\nBucket:{}\nKey:{}".\
                      format(bucket,key))        
        content_object = s3_resource.Object(bucket, key)
        config_content = content_object.get()['Body'].read().decode('utf-8')
        json_content = json.loads(config_content)
    except Exception as e:
        create_custom_log("ERROR",__name__,"Error Reading bucket.\nBucket:{}\nKey:{}\nError Details:{}".\
                      format(bucket,key,str(e)))  
        raise Exception("Error Reading bucket: " + str(e)) 
    return json_content


def get_job_configs(job_conf_base_path,config_filename):
    """
    Read config Files
    """    
    if config_filename == 'JobScheduleConfig':
        job_conf_file = '{}/{}_{}.json'.format(job_conf_base_path,sub_area.upper(),config_filename)
        create_custom_log("INFO",__name__,"Reading Job Schedule Configurations.\nFile:{}".format(job_conf_file))
        config_json = read_input_config(config_bucket_name,job_conf_file)
    elif config_filename == 'JobMapConfig':
        job_conf_file = '{}/{}_{}.json'.format(job_conf_base_path,job_name,config_filename)
        create_custom_log("INFO",__name__,"Reading Job Map Configurations.\nFile:{}".format(job_conf_file))
        config_json = read_input_config(config_bucket_name,job_conf_file)
    return config_json  


def get_common_configs():
    """
    Read config Files
    """
    try:
        create_custom_log("INFO",__name__,"Getting common configurations")  
        create_custom_log("INFO",__name__,"Bucket:{}\nBase Path:{}".\
                      format(config_bucket_name,base_path))  
        error_conf_file = '{}/{}'.format(base_path,"ErrorMessageConfig.json")
        dict_error_config = read_input_config(config_bucket_name,error_conf_file)
        proj_path_conf_file = '{}/BasePathMapConfig{}.json'.format(base_path,environment)        
        dict_proj_path_conf = read_input_config(config_bucket_name,proj_path_conf_file)
        audit_columns_detl_file = '{}/{}'.format(base_path,"JobAuditFields.json")
        dict_audit_columns_detl = read_input_config(config_bucket_name,audit_columns_detl_file)       
        create_custom_log("INFO",__name__,"Loaded common configurations")  
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in reading Common Configurations.\nBucket:{}\nBase Path:{}\nError Details:{}".\
                      format(config_bucket_name,base_path,str(e)))
        raise Exception("Exception in Get Common Configurations." + str(e))
    return dict_proj_path_conf ,dict_error_config,dict_audit_columns_detl 


def create_dataframe_from_json(fileFormat,file_path,rootTag,rowTag,mode,spark_schema=None):
    """
    : Creates dataframe from s3 file using parameters provided
    """
    input_data_df="None"
    print("rootTag : {} , rowTag :{}".format(rootTag,rowTag))
    try:
        if spark_schema is None:
            create_custom_log("INFO",__name__,"Creating dataframe with infer schema.\nFilepath:{}\nDelimiter:{}".\
                      format(file_path,delimiter))
            input_data_df = spark.read.format(fileFormat) \
                                    .option('mode',mode) \
                                    .load(file_path)
        else:
            create_custom_log("INFO",__name__,"Creating dataframe with custom schema.\nFilepath:{}\nDelimiter:{}".\
                      format(file_path,delimiter))
            input_data_df = spark.read.format(fileFormat) \
                                    .option('mode',mode) \
                                    .load(file_path, schema = spark_schema)
                                     
        create_custom_log("INFO",__name__,"Dataframe from json created successfully.")
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in Creating Dataframe from json.\nFilepath:{}\nDelimiter:{}\nError Details:{}".\
                      format(file_path,delimiter,str(e)))        
        job_status="FAILED"
        error_message=get_error_message(CREATE_DF_ERR_ID)
        raise Exception("Exception in Creating Dataframe from json" + str(e))
        
    return input_data_df


def create_dataframe(fileFormat,header,file_path,delimiter=",",spark_schema=None):
    """
    Creates dataframe from s3 file using parameters provided
    """
    input_data_df2="None"
    step_start_time = str(datetime.now())                                     
    try:
        if spark_schema is None:
            create_custom_log("INFO",__name__,"Creating dataframe with infer schema.\nFilepath:{}\nDelimiter:{}".\
                      format(file_path,delimiter))
            
            fileFormat="csv"
            input_data_df2 = spark.read.format(fileFormat) \
                                    .option('header',header) \
                                    .option('delimiter',delimiter)\
                                    .option('inferSchema',False) \
                                    .option('quote','')\
                                    .load(file_path)
                                    
            print("header",header)
            print("delimiter",delimiter)
            print("fileFormat",fileFormat)
        else:
            create_custom_log("INFO",__name__,"Creating dataframe with custom schema.\nFilepath:{}\nDelimiter:{}".\
                      format(file_path,delimiter))
            input_data_df2 = spark.read.format(fileFormat) \
                                     .option('header',header) \
                                      .option('delimiter',delimiter)\
                                      .option('schema',spark_schema) \
                                      .option('quote','')\
                                      .load(file_path)
        create_custom_log("INFO",__name__,"Dataframe created successfully.")
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in Creating Dataframe.\nFilepath:{}\nDelimiter:{}\nError Details:{}".\
                      format(file_path,delimiter,str(e)))        
        job_status="FAILED"
        error_message=get_error_message(CREATE_DF_ERR_ID) 
        prepare_job_audit(job_stage,job_status,0,0,0,0,0,0,0,\
                                step_start_time,'NA')                                                     
        raise Exception("Exception in Creating Dataframe" + str(e))
        
    return input_data_df2


def create_inputfile_dataframe(fileFormat,header,data_file_hdfs_path,rootTag,rowTag,spark_schema=None):
    """
    Creates dataframe from s3 file using parameters provided
    """
    partial_flattened_df="None"
    step_start_time = str(datetime.now())                                       
    try:
        if spark_schema is None:
            create_custom_log("INFO",__name__,"Creating dataframe with infer schema.\nFilepath:{}\nDelimiter:{}".\
                      format(data_file_hdfs_path,delimiter))
            permissive_input_df = create_dataframe_from_json(fileFormat,data_file_hdfs_path,rootTag,rowTag,'PERMISSIVE')            
        else:
            create_custom_log("INFO",__name__,"Creating dataframe with custom schema.\nFilepath:{}\nDelimiter:{}".\
                      format(data_file_hdfs_path,delimiter))
            permissive_input_df = create_dataframe_from_json(fileFormat,data_file_hdfs_path,rootTag,rowTag,'PERMISSIVE',spark_schema)
            
        full_flattened_df = full_flatten_df(create_dataframe_from_json(fileFormat,data_file_hdfs_path,rootTag,rowTag,'PERMISSIVE'))
        full_flattened_df1 = full_flattened_df.withColumn("File_Name", split(input_file_name(),'/')[7])
           
        data_with_input_file_df = permissive_input_df.withColumn("File_Name", split(input_file_name(),'/')[7])
        partial_flattened_df = flatten_df(data_with_input_file_df)

        create_custom_log("INFO",__name__,"Creating dataframe with custom schema.\nFilepath:{}\nDelimiter:{}".\
                      format("spark_schema",delimiter))

        create_custom_log("INFO",__name__,"Dataframe created successfully.")
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in Creating Dataframe.\nFilepath:{}\nDelimiter:{}\nError Details:{}".\
                      format("spark_schema",delimiter,str(e)))        
        job_status="FAILED"
        error_message=get_error_message(CREATE_DF_ERR_ID)
        prepare_job_audit(job_stage,job_status,0,0,0,0,0,0,0,step_start_time,'NA')
        raise Exception("Exception in Creating Dataframe" + str(e))
        
    return partial_flattened_df, full_flattened_df1


def delete_s3_file_list(bucket, prefix,file_prefix=None):      
    """
    Read config Files
    """
    try:
        create_custom_log("INFO",__name__,"Getting file list from S3.\nBucket:{}\nPrefix:{}".format(bucket,prefix))
        my_bucket = s3_resource.Bucket(bucket)
        for my_bucket_object in my_bucket.objects.filter(Prefix=prefix):
            if file_prefix == None:
                my_bucket_object.delete()
            else:
                if (my_bucket_object.key.split('/')[-1]).endswith(file_prefix):
                    my_bucket_object.delete()         
    except Exception as e:
        create_custom_log("ERROR",__name__,"Error geting filelist.\nBucket:{}\nPrefix:{}\nError:{}".format(bucket,prefix,str(e)))
        raise Exception("Error getting file list from S3 bucket."+str(e))


def flatten_xmldict_df():
    """
    : Fully flatten a json file using xmldict and jsonFlat library
    """
    print("validated json files path :{}".format(hdfs_validated_files_path))
    hdfs_validated_files_path_str = ",".join(hdfs_validated_files_path)
    hdfs_files = hdfs_validated_files_path_str.split(',')
    print("hdfs_files -",hdfs_files)
    for hdfs_file in hdfs_files:
        filename = hdfs_file.split('/')[-1].replace('dat','json')
        print("=====Reading file :{}".format(hdfs_file))
        data_df = spark.sparkContext.textFile(hdfs_file)
    
        #doc = xmltodict.parse("".join(data_df.collect()))
  
        data_list = data_df.collect()
        i = 0
        doc_dict = {}
        for ele in data_list:
            doc_dict[i]=json.loads(ele)
            i+=1
            
        if sub_area == 'MVR':
            tpdl_rep_docs = doc['tags']['tag']
        if sub_area == 'CLUEPI':
            tpdl_rep_docs = doc['tags']['handleInteractiveOrderResponse']
        if sub_area == 'IID' or sub_area == 'ADPF' or sub_area == 'IIDADPF':
            tpdl_rep_docs = doc['tags']['soap:Envelope']
        if sub_area == 'CARFAX' or sub_area == 'ZESTY' or sub_area.upper() == 'TNEDICCA':
            tpdl_rep_docs = doc_dict

        #flatten_data = list()

        for index,item in enumerate(tpdl_rep_docs):
            if sub_area == 'MVR':
                if 'list' in str(type(item['retrieveRiskReportsResponse'])):
                    for elem in item['retrieveRiskReportsResponse']:
                        tpdl_rep_doc = elem['handleRequestResponse']['ResponseEx']['Response']
                        flat_json = JsonFlat().flatten(tpdl_rep_doc)
                        #flatten_data.extend(flat_json['rows'])
                        path_key = 'part_flat_data/{}/{}_{}'.format(sub_area, filename,index)
                        s3object = s3_resource.Object(internal_process_bucket, path_key)
                        s3object.put(
                                    Body=(bytes(json.dumps(flat_json['rows']).encode('UTF-8'))),
                                    ServerSideEncryption='aws:kms',
                                    SSEKMSKeyId=PROC_KMS_KEY
                                )                     
                else:
                    tpdl_rep_doc = item['retrieveRiskReportsResponse']['handleRequestResponse']['ResponseEx']['Response']
                    flat_json = JsonFlat().flatten(tpdl_rep_doc)
                    #flatten_data.extend(flat_json['rows'])  
                    path_key = 'part_flat_data/{}/{}_{}'.format(sub_area, filename,index)
                    s3object = s3_resource.Object(internal_process_bucket, path_key)
                    s3object.put(
                                Body=(bytes(json.dumps(flat_json['rows']).encode('UTF-8'))),
                                ServerSideEncryption='aws:kms',
                                SSEKMSKeyId=PROC_KMS_KEY
                            )
                    
            elif sub_area == 'CLUEPI':
                    tpdl_rep_doc = item['response']['result']
                    flat_json = JsonFlat().flatten(tpdl_rep_doc)
                    #flatten_data.extend(flat_json['rows'])
                    path_key = 'part_flat_data/{}/{}_{}'.format(sub_area, filename,index)
                    s3object = s3_resource.Object(internal_process_bucket, path_key)
                    s3object.put(
                                Body=(bytes(json.dumps(flat_json['rows']).encode('UTF-8'))),
                                ServerSideEncryption='aws:kms',
                                SSEKMSKeyId=PROC_KMS_KEY
                            )                 
            elif sub_area == 'IID' or sub_area == 'ADPF' or sub_area == 'IIDADPF':
                    tpdl_rep_doc = item['soap:Body']['handleRequestResponse']['ResponseEx']['Response']
                    flat_json = JsonFlat().flatten(tpdl_rep_doc)
                    #flatten_data.extend(flat_json['rows'])                    
                    path_key = 'part_flat_data/{}/{}_{}'.format(sub_area, filename,index)
                    s3object = s3_resource.Object(internal_process_bucket, path_key)
                    s3object.put(
                                Body=(bytes(json.dumps(flat_json['rows']).encode('UTF-8'))),
                                ServerSideEncryption='aws:kms',
                                SSEKMSKeyId=PROC_KMS_KEY
                            )
                   
            elif sub_area == 'CARFAX' or sub_area == 'ZESTY' or sub_area.upper() == 'TNEDICCA':
                    tpdl_rep_doc = tpdl_rep_docs[index]
                    flat_json = JsonFlat().flatten(tpdl_rep_doc)
                    #flatten_data.extend(flat_json['rows'])                    
                    path_key = 'part_flat_data/{}/{}_{}'.format(sub_area, filename,index)
                    s3object = s3_resource.Object(internal_process_bucket, path_key)
                    s3object.put(
                                Body=(bytes(json.dumps(flat_json['rows']).encode('UTF-8'))),
                                ServerSideEncryption='aws:kms',
                                SSEKMSKeyId=PROC_KMS_KEY
                            )
            
    json_path = 's3://{}/part_flat_data/{}/'.format(internal_process_bucket,sub_area)
    print('Reading flattened json from path :{}'.format(json_path))
    dff = spark.read.json(json_path)
    dff2 = dff.withColumn("File_Name", split(input_file_name(),'/')[5])
    file_len = len (dff2.select('File_Name').collect()[0][0].split('.')[0] ) 
    print('Data file length without extension :{}'.format(file_len))
    dff2 = dff2.withColumn('File_Name',concat(substring('File_Name',1,file_len),lit('.dat')) )
    
    dff2.printSchema()
    for coln in dff2.columns:
        dff2 = dff2.withColumnRenamed(coln, coln.replace('.','_'))
    print("after code fix by replacing . with _")
    dff2.printSchema()
    #dff2.select(['Report_ID','File_Name']).show(5,truncate=False)
    dff2.count()

    return dff2 
    

def full_flatten_df(nested_df):
    """
    : Recursively flattens nested dataframe
    : Returns flat dataframe
    """
    for col in nested_df.columns:
        array_cols = [c[0] for c in nested_df.dtypes if c[1][:5]=='array']
        
    for col in array_cols:
        nested_df = nested_df.withColumn(col, f.explode_outer(nested_df[col]))
    
    flat_cols = [c[0] for c in nested_df.dtypes if c[1][:6] != 'struct']
    nested_cols = [c[0] for c in nested_df.dtypes if c[1][:6] == 'struct']
    
    if len(nested_cols) == 0:
        return nested_df
    
    flat_df = nested_df.select(flat_cols +
                              [f.col(nc +'.' +c).alias(nc +'_'+ c)
                               for nc in nested_cols
                               for c in nested_df.select(nc + '.*').columns])
    
    return full_flatten_df(flat_df)


def flatten_df(nested_df):
    """
    : Recursively flattens nested dataframe (struct fields only)
    : Returns flattened dataframe with each level conacatenated by underscore
    """
    flat_cols = [c[0] for c in nested_df.dtypes if c[1][:6] != 'struct']
    nested_cols = [c[0] for c in nested_df.dtypes if c[1][:6] == 'struct']
    
    if len(nested_cols) == 0:
        return nested_df
    
    flat_df = nested_df.select(flat_cols +
                              [f.col(nc +'.' +c).alias(nc +'_'+ c)
                               for nc in nested_cols
                               for c in nested_df.select(nc + '.*').columns])
    
    return flatten_df(flat_df)


def get_ctrl_files_path(valid_file_list):
    ctrl_file_list = []
    ctrl_file_path_list = []
    for valid_file in valid_file_list:
        ctrl_file = valid_file.replace('dat.gz','ctrl')
        ctrl_file_list.append(ctrl_file)
    print('ctrl_file_list :{}'.format(ctrl_file_list))
    for ctrl_file in ctrl_file_list:
        ctrl_file_path = '{}{}'.format(full_qualified_data_file_name,ctrl_file)
        ctrl_file_path_list.append(ctrl_file_path)
    return ctrl_file_path_list


def get_data_file_list(valid_ctrl_files):
    'returns list of data files from ctrl file list'
    data_file_list = []
    for ctrl_file in valid_ctrl_files:
        data_file = ctrl_file.replace('ctrl','dat')
        data_file_list.append(data_file)
        
    return data_file_list

def get_dataframes(step_id,hdfs_validated_files_path):
    step_desc="Create Dataframe"  
    global custom_schema 
    global full_flattened_df                                                
    try:
        create_custom_log("INFO",__name__,"Dataframe Creation started")
        step_start_time=str(datetime.now())
        # Read partial flattened custom schema
        custom_schema_path = "{}/{}Schema.json".format(schema_dir_path,sub_area)   
        custom_schema_dict = read_input_config(config_bucket_name,custom_schema_path)
        custom_schema = StructType.fromJson(custom_schema_dict)
        input_data_df, full_flattened_df = create_inputfile_dataframe(sparkFileFormat,header,hdfs_validated_files_path,rootTag,rowTag,custom_schema)
        raw_schema=None
        raw_input_data_df, raw_full_flattened_df = create_inputfile_dataframe(sparkFileFormat,header,hdfs_validated_files_path,rootTag,rowTag,raw_schema)
        step_status="SUCCESS"
        error_message=None
        create_custom_log("INFO",__name__,"Dataframe Creation started completed successfully.")               

    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in Dataframe Creation ")
        step_status="FAILED"
        error_message=get_error_message(CREATE_DF_ERR_ID)
        create_email_details(step_status,error_message)
        raise Exception("Exception in Dataframe Creation process." + str(e))
    finally:
        step_end_time=str(datetime.now())
        prepare_jobstep_audit(step_id,step_desc, \
                                    step_start_time,step_end_time,step_status,'NA',error_message)
    return input_data_df, full_flattened_df,raw_input_data_df


def get_error_message(msg_id):
    """
    Read error message from config
    """
    global lst_error_detl
    create_custom_log("INFO",__name__,"Retreiving Error Messages.\nErrorID:{}".format(msg_id))  

    error_message_desc=[error_message.get("MsgDescription")  for error_message in lst_error_detl if error_message.get("ErrorMsgId")==msg_id][0]
    return error_message_desc


def get_job_step_active(jobstepid,list_job_configs):
    """
    Read config Files
    """
    active_flag=[jobstep.get("Active")  for jobstep in list_job_configs if jobstep.get("JobStepId")==jobstepid][0]    
    result = True if active_flag in ('Y','M') else False
    return result


def record_count_validation(step_id,control_file_df):
    """
    Read config Files
    """
    step_desc="Record Count Validation"
    step_start_time = str(datetime.now())                                   
    try:
        global count_valiadted_file_list
        global datfile_rec_count_dict
        global ctrl_file_rec_count_dict
        global decrypt_rec_count_dict
        global decrypt_err_rec_count_dict
        global total_decrypt_err_rec_count   
        global invalid_total_decrypt_err_rec_count        
        global total_record_count
        global invalid_datafile_count
        global invalid_ctrl_count 
        global hdfs_validated_files_path
        total_record_count =0 
        total_decrypt_err_rec_count = 0  
        invalid_total_decrypt_err_rec_count = 0
        invalid_datafile_count = 0
        invalid_ctrl_count = 0
        decrypt_err_rec_count = 0   
        IsCountMatched = False        
        create_custom_log("INFO",__name__,"Record Count Validation is started")
        step_start_time=str(datetime.now())
        
        # validate count between ctrl file and decrypted file csv details
        data_file_path = "s3://{}/record_count/{}/*csv".format(internal_process_bucket,sub_area)
        decrypted_count_df = create_dataframe('csv',True,data_file_path,delimiter=",")
        decrypted_count_filewise_df = decrypted_count_df.withColumn("File_Name", split(input_file_name(),'/')[5])
        decrypted_count_filewise_df2 = decrypted_count_filewise_df.withColumn('File_Name',regexp_replace('File_Name','csv','dat.gz'))
        decrypted_count_filewise_df2 = decrypted_count_filewise_df2.withColumnRenamed('Tot_Inp_Record_Count','Record_Count')
        joined_data_df = decrypted_count_filewise_df2.join(control_file_df,on = ['File_Name','Record_Count'],how='inner')

        count_valiadted_file_list = joined_data_df.select(['File_Name']).rdd.flatMap(lambda x: x).collect()

        ctrl_file_rec_count_dict = control_file_df.select(['File_Name','Record_Count']).rdd.map(lambda x: (x[0],x[1])).collectAsMap()
        print('ctrl_file_rec_count_dict :{}'.format(ctrl_file_rec_count_dict)) 
        
        #Getting Encrypted record count of data file
        datfile_rec_count_dict = decrypted_count_filewise_df2.select(['File_Name','Record_Count']).rdd.map(lambda x: (x[0],int(x[1]))).collectAsMap() 
        print("datfile_rec_count_dict :{}".format(datfile_rec_count_dict))
        #Getting Decrypted record count from XML file
        decrypt_rec_count_dict = decrypted_count_filewise_df2.select(['File_Name','Tot_Decrypted_Rec_Count']).rdd.map(lambda x: (x[0],int(x[1]))).collectAsMap() 
        print("decrypt_rec_count_dict :{}".format(decrypt_rec_count_dict))  
        #Getting Decryption Error record count of data file        
        decrypt_err_rec_count_dict = decrypted_count_filewise_df2.select(['File_Name','Decrypted_Error_Count']).rdd.map(lambda x: (x[0],int(x[1]))).collectAsMap() 
        print("decrypt_err_rec_count_dict :{}".format(decrypt_err_rec_count_dict))                                                                                                                                                                   
        hdfs_validated_files = [file_name.replace('dat.gz','dat') for file_name in count_valiadted_file_list]
        print("hdfs_validated_files :{}".format(hdfs_validated_files))
        invalid_count_files = list(set(unprocessed_files) - set(count_valiadted_file_list))
        print("invalid_count_files :{}".format(invalid_count_files))
        

        if len(invalid_count_files) > 0:
            input_data_df=spark.createDataFrame([],StructType([])) # creating empty dataframe for return variable
            datatype_mismatch_df=input_data_df
            full_flattened_df=datatype_mismatch_df
            step_end_time=str(datetime.now())
            step_status="FAILED"
            
            error_message=get_error_message(REC_CNT_VAL_ERR_ID)  
            for invalid_file in invalid_count_files:
                datafile_rec_cnt = datfile_rec_count_dict[invalid_file]
                invalid_datafile_count += datafile_rec_cnt
                ctrl_file_rec_cnt = ctrl_file_rec_count_dict[invalid_file]
                invalid_ctrl_count += int(ctrl_file_rec_cnt)
                invalid_decrypt_rec_cnt=decrypt_rec_count_dict[invalid_file]
                invalid_decrypt_err_rec_count = decrypt_err_rec_count_dict[invalid_file]
                invalid_total_decrypt_err_rec_count += invalid_decrypt_err_rec_count                  
                prepare_jobstep_audit(step_id,step_desc, step_start_time,step_end_time,step_status,invalid_file,error_message)
                prepare_job_audit(job_stage,step_status,datafile_rec_cnt,ctrl_file_rec_cnt,invalid_decrypt_rec_cnt,invalid_decrypt_err_rec_count,0,0,0,\
                                step_start_time,invalid_file)
            job_status="FAILED"   
            message="Record Count Validation Failed.. \nCount in Control File: {}\nCount in Data File: {}\nFile Names:\n{}".\
            format(invalid_ctrl_count,invalid_datafile_count,"\n".join(filename for filename in invalid_count_files ))
            create_email_details(job_status,message)                                
            send_sns_notification()
            
        if len(count_valiadted_file_list)>0:

            hdfs_validated_files_path = ""
            hdfs_path_list = []
            for hdfs_file in hdfs_validated_files:
                complete_hdfs_path = "{}/{}".format(data_file_hdfs_path,hdfs_file)
                hdfs_path_list.append(complete_hdfs_path)
            #hdfs_validated_files_path = ",".join(hdfs_path_list)
            hdfs_validated_files_path=hdfs_path_list
            
            print("hdfs_validated_files_path :{}".format(hdfs_validated_files_path))
            
            input_data_df,full_flattened_df,raw_input_data_df = get_dataframes(CREATE_DF_STEP_ID,hdfs_validated_files_path)
            
            #adding malformed df
            malformed_input_df = create_dataframe_from_json(sparkFileFormat,hdfs_validated_files_path,rootTag,rowTag,'DROPMALFORMED',custom_schema)
            data_with_input_file_df2 = malformed_input_df.withColumn("File_Name", split(input_file_name(),'/')[7])
            partial_malformed_flattened_df = flatten_df(data_with_input_file_df2)
            datatype_mismatch_df = input_data_df.exceptAll(partial_malformed_flattened_df)
        
            IsCountMatched = True
            step_status="SUCCESS"
            error_message=None
            step_end_time=str(datetime.now())
            print('populating data and ctrl file count ')  
            for valid_file in count_valiadted_file_list:
                print("valid_file :{}".format(valid_file))
                datafile_rec_cnt = datfile_rec_count_dict[valid_file]
                ctrl_file_rec_cnt = ctrl_file_rec_count_dict[valid_file]     
                decrypt_rec_cnt=decrypt_rec_count_dict[valid_file]                                
                decrypt_err_rec_count = decrypt_err_rec_count_dict[valid_file]
                total_record_count += decrypt_rec_cnt + decrypt_err_rec_count
                total_decrypt_err_rec_count += decrypt_err_rec_count                                                                 
                create_custom_log("INFO",__name__,"Count Matched. Control File Count: {}.Data File Count:{}".\
                      format(ctrl_file_rec_cnt,datafile_rec_cnt))
                print("Count Matched. Control File Count: {}.Data File Count:{}".format(ctrl_file_rec_cnt,datafile_rec_cnt))
                
                prepare_jobstep_audit(step_id,step_desc, step_start_time,step_end_time,step_status,valid_file,error_message)
        else:
            create_custom_log("INFO",__name__,"Count MisMatched for all data and control file pair")
            IsCountMatched = False
             
                                
        create_custom_log("INFO",__name__,"Record Count Validation is completed")
    except Exception as e:
        step_status="FAILED"
        error_message=get_error_message(REC_CNT_VAL_EXP_ERR_ID)
        create_email_details(step_status,error_message) 
        prepare_job_audit(job_stage,step_status,0,0,0,0,0,0,0,step_start_time,'NA')                                                                                        
        create_custom_log("ERROR",__name__,"{}\nDetails:{}".format(error_message,str(e)))
        raise Exception("Exception in Record Count Validation process."+str(e))
    finally:
        step_end_time=str(datetime.now())
    return IsCountMatched,input_data_df,datatype_mismatch_df,full_flattened_df,raw_input_data_df 


def write_to_datalake(step_id,datalake_df,dict_file_metadata,datalake_bucket,mode='append'):    
    """
    Read config Files
    """

    df_type="Valid"
    step_desc="Valid Records Write to {} Datalake ".format(datalake_bucket.split('-')[-1])     
    global datalake_prefix_path
    create_custom_log("INFO",__name__,"Writing {} data to Datalake started.".format(df_type))
    
    try:
        input_data_df = datalake_df.withColumn('Job_Key',lit(job_key))

        step_start_time=str(datetime.now()) 
        print("datalake bucket : {}".format(datalake_bucket))
        print("datalake key : {}".format(datalake_prefix_path))
        datalake_path = 's3://{}/{}'.format(datalake_bucket,datalake_prefix_path)
        for column in input_data_df.columns:
            input_data_df=input_data_df.withColumnRenamed(column,column.strip()).withColumnRenamed(column,column.replace("-","_"))
        
        print("DATA_KMS_KEY",DATA_KMS_KEY)
        print("datalake_path",datalake_path)

        coalesce_number = 5
        print('coalesce number :{}'.format(coalesce_number))
        
        if (partition_col.strip()==""):
            input_data_df.coalesce(coalesce_number).write.mode("append").parquet(datalake_path)
        elif len(partition_col.split(',')) >1:
            partition_cols = list()
            part_by_cols = list()
            partition_cols = partition_col.split(',')
            for coln in partition_cols:
                input_data_df = input_data_df.withColumnRenamed(coln,coln.lower())
            input_null_part_col_data_df = input_data_df.filter(f.col(partition_cols[0]).isNull() & f.col(partition_cols[1]).isNull())            
            input_not_null_part_col_data_df = input_data_df.filter(f.col(partition_cols[0]).isNotNull() & f.col(partition_cols[1]).isNotNull())            

            for part_col in partition_cols:
                part_by_cols.append("{}".format(part_col.lower()))
            print('partition cols :{}'.format(part_by_cols))
            null_part_col_rec_count= len(input_null_part_col_data_df.head(1))             
            not_null_part_col_rec_count = len(input_not_null_part_col_data_df.head(1))

            if not_null_part_col_rec_count>0:                    
                input_not_null_part_col_data_df.write.mode("append").partitionBy(*part_by_cols).parquet(datalake_path)
            if null_part_col_rec_count>0:
                        input_null_part_col_data_df.write.mode("append").partitionBy(*part_by_cols).parquet(datalake_path)

        else:
            part_by_cols=list()             
            if sub_area.upper() == 'TNEDICCA':
                input_format="yyyy-MM-dd HH:mm:ss"
            else:
                input_format="yyyy-MM-dd"
            
            part_cols_fmts=partition_by_fmt.split(",") 
            input_null_part_col_data_df=input_data_df.where(f.col(partition_col).isNull())            
            input_not_null_part_col_data_df=input_data_df.where(f.col(partition_col).isNotNull())            
            null_part_col_rec_count= len(input_null_part_col_data_df.head(1))             
            not_null_part_col_rec_count = len(input_not_null_part_col_data_df.head(1))                   
            for part_fmt in part_cols_fmts:
                if not_null_part_col_rec_count>0:
                    if part_fmt=="year":
                        col_val=f.year(f.to_timestamp(f.col(partition_col),input_format))
                    if part_fmt=="month":
                        col_val=f.month(f.to_timestamp(f.col(partition_col),input_format))
                    if part_fmt=="day":
                        col_val=f.dayofmonth(f.to_timestamp(f.col(partition_col),input_format))
                    input_not_null_part_col_data_df=input_not_null_part_col_data_df.withColumn("{}_{}".format(partition_col.lower(),part_fmt),col_val)
                
                if null_part_col_rec_count >0:
                    input_null_part_col_data_df=input_null_part_col_data_df.withColumn("{}_{}".format(partition_col.lower(),part_fmt),f.lit(''))

                part_by_cols.append("{}_{}".format(partition_col.lower(),part_fmt)) 
                
            if not_null_part_col_rec_count>0:                    
                input_not_null_part_col_data_df.coalesce(coalesce_number).write.mode("append").partitionBy(*part_by_cols).parquet(datalake_path)
            if null_part_col_rec_count>0:
                input_null_part_col_data_df.coalesce(coalesce_number).write.mode("append").partitionBy(*part_by_cols).parquet(datalake_path)        
        
        create_custom_log("INFO",__name__,"Writing {} data to Datalake completed.".format(df_type))        
        step_status="SUCCESS"
        error_message=None
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in write {} records to datalake.".format(df_type))
        step_status="FAILED"
        error_message=get_error_message(MOVE_VALID_TO_DL_ERR_ID)
        create_email_details(step_status,error_message)                                                                                                            
        raise Exception("Exception in writing {} data to datalake.\nDetails:{}".format(df_type,str(e)))
    finally:        
        step_end_time=str(datetime.now())
        prepare_jobstep_audit(step_id,step_desc, \
                                    step_start_time,step_end_time,step_status,'NA',error_message)
def write_to_error(step_id,invalid1_df,prev_fail_step_id,mode='append',numPartitions=1,Header=True):    

    df_type="Invalid"
    step_desc="Invalid Records Write to Error"    
    create_custom_log("INFO",__name__,"Writing {} data to Error started.".format(df_type))
    try:
        step_start_time=str(datetime.now())
        process_year=datetime.strptime(process_date,"%Y%m%d_%H%M%S_%f").year
        process_month=datetime.strptime(process_date,"%Y%m%d_%H%M%S_%f").month  #data_file_name
        #error_datatype_schema = StructType([StructField('Report_ID', StringType(), True),
                                            #StructField('SEQ_No', IntegerType(), True),
                                            #StructField('Indicator',StringType(),True)
          
        #print(type(invalid1_df))
        #print("*****error*****")
        
        
        for column in invalid1_df.columns:
            error_data_df=invalid1_df.withColumnRenamed(column,column.strip())
            
        error_data_df = error_data_df.withColumn('Processed_timestamp',lit(str_datetime))
            
        #error_data_df = error_data_df.withColumn('Start_time', error_data_df.Start_time + f.expr('INTERVAL 1 SECOND'))
         
        error_data_df = error_data_df.withColumn('Job_Key',lit(job_key))
         
        #print(type(error_data_df))
        #print(error_data_df.columns)
        #print("print column names")
               
        error_file_path_write = 's3://{}/{}'.format(internal_process_bucket,error_file_path)
        
        error_data_df.coalesce(1).write.mode("append").parquet(error_file_path_write)
       
        create_custom_log("INFO",__name__,"Writing {} data to Error completed.".format(df_type))
        step_status="SUCCESS"
        error_message=None
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in write {} records to Error.".format(df_type))
        step_status="FAILED"
        error_message=get_error_message(MOVE_INVALID_TO_DL_ERR_ID)
        create_email_details(step_status,error_message)
        raise Exception("Exception in writing {} data to Error.\nDetails:{}".format(df_type,str(e)))
    finally:        
        step_end_time=str(datetime.now())
        prepare_jobstep_audit(step_id,step_desc, \
                                    step_start_time,step_end_time,step_status,'NA',error_message)
        
def repair_table(step_id,db_name):
    """
    Repair table
    """
    step_desc="Spark: Repair Table"    
    create_custom_log("INFO",__name__,"Repair table.")
    starttime = str(datetime.now())
    try:
        step_start_time=str(datetime.now())
        table_name = "{}_report".format(sub_area) 
        spark.sql("msck repair table {}.{}".format(db_name,table_name))
        create_custom_log("INFO",__name__,"Repair table completed.")
        step_status="SUCCESS"
        error_message=None
        for valid_file in count_valiadted_file_list:
            step_end_time=str(datetime.now())
            prepare_jobstep_audit(step_id,step_desc, \
                                    step_start_time,step_end_time,step_status,valid_file,error_message)  
            
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in Repairing table.")
        step_status="FAILED"
        job_status="FAILED"
        error_message=get_error_message(REPAIR_TABLE_ERR_ID)
        for valid_file in count_valiadted_file_list:
            step_end_time=str(datetime.now())
            prepare_jobstep_audit(step_id,step_desc, \
                                    step_start_time,step_end_time,step_status,valid_file,error_message)
            prepare_job_audit(job_stage,job_status,0,0,0,0,0,0,0,starttime,valid_file)
        create_email_details(step_status,error_message)
        raise Exception("Exception in Repairing table.\nDetails:{}".format(str(e)))
    finally:        
        step_end_time=str(datetime.now())

        
def get_extra_schema_column(input_data_columns):
    """
    : Return list of extra columns which are not in custom schema provided
    """
    full_flattened_schema_path = "full_flattened_schema/{}_MetaData.json".format(sub_area)  
    full_flattened_schema_dict = read_input_config(config_bucket_name,full_flattened_schema_path)
    flattened_schema_columns = []
    valid_columns = []                  
    for coln in full_flattened_schema_dict['ColumnDetails']:
        flattened_schema_columns.append(coln['ColumnName'])
    input_data_columns=[item.lower() for item in input_data_columns]
    flattened_schema_columns=[item.lower() for item in flattened_schema_columns]
    extra_columns = list(set(input_data_columns) - set(flattened_schema_columns))
    valid_columns = list(set(input_data_columns) - set(extra_columns))
    #print("input_data_columns: ",input_data_columns)
    #print(len(input_data_columns))
    #print("extra_columns: ",extra_columns)
    #print(len(extra_columns))
    #print("valid_columns: ",valid_columns)
    #print(len(valid_columns))    
    
    return extra_columns,valid_columns


def move_s3_files(s3_source_path,s3_target_path,file_name):
    try:
        source_key_val="{}{}".format(s3_source_path,file_name)
        target_key_val="{}/{}".format(s3_target_path,file_name)
        print(" source bucket :{}".format(bucket_name))
        print("source_key_val:"+source_key_val)
        print("target_key_val:"+target_key_val)
        copy_source = {
                'Bucket': bucket_name,
                'Key': source_key_val 
                }
        dest_bucket = s3_resource.Bucket(internal_process_bucket)
        print("PROC_KMS_KEY",PROC_KMS_KEY)
            
        dest_bucket.copy(copy_source, target_key_val,ExtraArgs={'ServerSideEncryption':'aws:kms','SSEKMSKeyId':PROC_KMS_KEY})
        obj = s3_resource.Object(bucket_name, source_key_val)
        obj.delete()            
    except Exception as e:
        raise Exception("Error copying file from S3 bucket."+str(e))                


def write_error_records(error_df):
    print("write to error path started") 

    error_path_key  = "error/{}/schema-mismatch/".format(sub_area)  
    error_data_path = "s3://{}/{}".format(internal_process_bucket,error_path_key)
    print("error_data_path :{}".format(error_data_path))
    error_df.coalesce(1).write.mode("append").csv(error_data_path, header='true')
    print("write to error path completed")  
    
    
def move_files_to_archive(step_id,bucket,data_file_name,control_file_name):
    """
    move files from inbound to archive
    """
    step_desc="Move Files to Archive"
    create_custom_log("INFO",__name__,"Moving file from Inbound to Archive started.")
    try:
        step_start_time=str(datetime.now()) 
        data_file_key_val=data_file_prefix
        archive_key_val="{}/{}".format(archive_file_path,data_file_name)        
        move_s3_files(data_file_key_val,archive_file_path,data_file_name)
        
        control_file_key_val=data_file_key_val
        archive_key_val="{}/{}".format(archive_file_path,control_file_name)
        move_s3_files(control_file_key_val,archive_file_path,control_file_name)

        step_status="SUCCESS"
        error_message=None
        create_custom_log("INFO",__name__,"Moving file from Inbound to Archive completed.File:{} and {}".format(data_file_name,control_file_name))
    except Exception as e:
        create_custom_log("ERROR",__name__,"Exception ocurred in Move data To Archive.")
        step_status="FAILED"
        error_message=get_error_message(MOVE_TO_ARC_ERR_ID)
        # generate audit
        starttime = str(datetime.now())
        prepare_job_audit(job_stage,step_status,0,0,0,0,0,0,0,starttime,data_file_name) 
        create_email_details(step_status,error_message)
        raise Exception("Exception in Move data To Archive process."+str(e))
    finally:
        step_end_time=str(datetime.now())
        prepare_jobstep_audit(step_id,step_desc, \
                                    step_start_time,step_end_time,step_status,data_file_name,error_message)

        
def mask_data_zesty(nested_struct_data):
    """
    Place holder for array data masking. Need to modify this code if any array field is added in ZESTY in future.
    Follow IID/ADPF/IIDADPF/MVR/CLUEPI masking logic from thirdparty spark code.
    """
        
    return nested_struct_data


def process_data(control_df, prev_fail_step_id=0):  
    """
    data processing method
    """
    #Validation attributes
    lst_validation_cols=list()
    #Declare different counts
    global data_file_rec_cnt
    global total_record_count
    global total_decrypt_err_rec_count                                     
    global ctl_file_rec_cnt
    global valid_data_cnt
    global invalid_data_cnt
    global count_valiadted_file_list 
    global invalid_data_cnt_dict 
    total_record_count = 0 
    total_decrypt_err_rec_count= 0                                                                                                                                            

    try:      
        if prev_fail_step_id<=MOVE_INVALID_TO_DL_STEP_ID:
            isRecCountValidated,cleansed_df,datatype_mismatch_df,full_flattened_df,raw_input_data_df = record_count_validation(REC_CNT_VAL_STEP_ID,control_df)
            
            if isRecCountValidated:
                error_datatype_schema = StructType([StructField('Report_ID', StringType(), True),
                                        StructField('SEQ_No', IntegerType(), True),
                                        StructField('File_Name', StringType(), True),
                                        StructField('Datatype_Mismatch', StringType(), True)])
                
                datatype_mismatch_df2 = spark.createDataFrame([], error_datatype_schema)  
                if datatype_mismatch_df.count() > 0:
                    datatype_mismatch_df2 = datatype_mismatch_df.select('Report_Id','File_Name','SEQ_No').withColumn('Datatype_Mismatch',f.lit('Y'))             
                input_data_columns = full_flattened_df.columns
                print("input data colums -",input_data_columns)
                extra_column_list,valid_column_list = get_extra_schema_column(input_data_columns)
                if 'file_name' in extra_column_list:
                    extra_column_list.remove('file_name')
                extra_column_count=len(extra_column_list)  
                print("extra_column_list than schema provided :{}".format(extra_column_list)) 
                
                error_data_schema = StructType([StructField('Report_ID', StringType(), True),
                                    StructField('SEQ_No', IntegerType(), True),
                                    StructField('File_Name', StringType(), True),
                                    StructField('New_Columns', StringType(), True),
                                    StructField('Schema_Mismatch', StringType(), True)])
                                    
                error_schema_df2 = spark.createDataFrame([], error_data_schema) 
                complete_error_df = spark.createDataFrame([], error_data_schema)                
                if len(extra_column_list) > 0:
                    job_status = 'Schema mismatch notification'
                    message = '{} Extra Column received on:{}\nExtra column list:\n{}'.format(extra_column_count,file_process_date,extra_column_list)
                    create_email_details(job_status,message)
                    #send_sns_notification()
                    complete_error_df = error_schema_df2.join(datatype_mismatch_df2,on= ['Report_ID','File_Name','SEQ_No'],how='outer') 
                    filewise_error_df = complete_error_df.groupBy('File_Name').count()                    
                    err_key_col_list =[]
                    invalid_data_cnt_dict = defaultdict(lambda:0)                    
                    invalid_data_cnt = complete_error_df.count()

                    if invalid_data_cnt > 0:
                        key_col_df = complete_error_df.withColumn('key_column',concat_ws('_','Report_ID','SEQ_No'))
                        err_key_col_list = key_col_df.select('key_column').rdd.map(lambda x:x[0]).distinct().collect()
                        #print(err_key_col_list)
                        invalid_data_cnt_dict = filewise_error_df.select(['File_Name','count']).rdd.map(lambda x: (x[0],x[1])).collectAsMap()                     
                    
                    key_col_cleansed_df = cleansed_df.withColumn('key_column',concat_ws('_','Report_ID','SEQ_No'))
                    valid_df = key_col_cleansed_df.filter(~key_col_cleansed_df['key_column'].isin(err_key_col_list))
                    #valid_df=key_col_cleansed_df
                    valid_df2 = valid_df.drop('key_column')
                    #valid_df2=valid_df2.select(*valid_column_list)
                    valid_data_cnt = valid_df2.count()
                    print("count of records : {}".format(valid_data_cnt))
                    dict_file_metadata=""  
                    valid_df2 = valid_df2.withColumn('Processed_timestamp',lit(str_datetime))                   
                    write_to_datalake(MOVE_VALID_TO_DL_STEP_ID,valid_df2,dict_file_metadata,confidential_datalake_bucket, mode='append')
                    full_flattened_mxldict_df = flatten_xmldict_df()
                    #full_flattened_mxldict_df.show()
                    print("full_flattened_mxldict_df:",full_flattened_mxldict_df)
                    #extra_column_list2= [val for val in extra_column_list if not val.endswith("_VALUE")]
                    #print("extra_column_list2:",extra_column_list2)
                    print("extra_column_list:",extra_column_list)                                                             
                    cond_expr=f.col(extra_column_list[0]).isNotNull()
                    for col_name in extra_column_list[1:]:
                        cond_expr |=f.col(col_name).isNotNull()
                    print(cond_expr)
                    full_flattened_extra_col_df = full_flattened_mxldict_df.select('Report_ID','File_Name','SEQ_No',*extra_column_list)                                                                                                           
                    full_flattened_extra_col_df.persist()                                             
                    full_flattened_extra_col_df.count()                                                                                            
                    error_schema_df = full_flattened_extra_col_df.select('Report_ID','File_Name','SEQ_No').distinct().where(cond_expr)
                    error_schema_df2 = error_schema_df.withColumn('New_Columns',f.lit(str(extra_column_list))).withColumn('Schema_Mismatch',f.lit('Y'))
                complete_error_df = error_schema_df2.join(datatype_mismatch_df2,on= ['Report_ID','File_Name','SEQ_No'],how='outer')
                filewise_error_df = complete_error_df.groupBy('File_Name').count()
                err_key_col_list =[]
                invalid_data_cnt_dict = defaultdict(lambda:0)
                    
                invalid_data_cnt = complete_error_df.count()
                if invalid_data_cnt > 0:
                    key_col_df = complete_error_df.withColumn('key_column',concat_ws('_','Report_ID','SEQ_No'))
                    err_key_col_list = key_col_df.select('key_column').rdd.map(lambda x:x[0]).distinct().collect()
                    invalid_data_cnt_dict = filewise_error_df.select(['File_Name','count']).rdd.map(lambda x: (x[0],x[1])).collectAsMap()
                    #complete_error_df.show()
                    complete_error_df2 = complete_error_df.withColumn('Processed_timestamp',lit(str_datetime)) 
                    write_error_records(complete_error_df2)
                    extra_col_Report_ID_list=[]
                    extra_col_Report_ID_list=complete_error_df.select('Report_ID').rdd.flatMap(lambda x: x).collect()

                    if None in extra_col_Report_ID_list:
                        extra_col_Report_ID_list=[y for y in extra_col_Report_ID_list if y is not None]
                    
                    temp_extra_col_df=raw_input_data_df.filter(~raw_input_data_df['Report_ID'].isin(extra_col_Report_ID_list))
                    extra_col_df=raw_input_data_df.exceptAll(temp_extra_col_df)
                    #print("extra_col_df")
                    #extra_col_df.show()
                    write_to_error(MOVE_INVALID_TO_DL_STEP_ID,extra_col_df,prev_fail_step_id,'append',1,'True')

                    
                
                for filename in count_valiadted_file_list:
                    xml_file = filename.replace('dat.gz','dat')
                    if xml_file not in invalid_data_cnt_dict.keys():
                            invalid_data_cnt_dict[xml_file] = 0                                                                
                print('invalid count dict :{}'.format(invalid_data_cnt_dict))
                print("err_report_id_list :{}".format(err_key_col_list))
                    
                if len(extra_column_list) == 0:    
                    key_col_cleansed_df = cleansed_df.withColumn('key_column',concat_ws('_','Report_ID','SEQ_No'))
                    valid_df = key_col_cleansed_df.filter(~key_col_cleansed_df['key_column'].isin(err_key_col_list))
                    valid_df2 = valid_df.drop('key_column')
                    valid_df2 = valid_df2.withColumn('Processed_timestamp',lit(str_datetime))
                    valid_data_cnt = valid_df2.count()
                    print("count after eror record filter : {}".format(valid_data_cnt))
   
                    create_custom_log("INFO",__name__,"valid data count:{} ".format(valid_data_cnt))                
                    #Move Valid Processed data into Datalake from Process Zone
                    dict_file_metadata=""

                    if valid_data_cnt >0 and prev_fail_step_id<MOVE_INVALID_TO_DL_STEP_ID:
                        write_to_datalake(MOVE_VALID_TO_DL_STEP_ID,valid_df2,dict_file_metadata,confidential_datalake_bucket,
                                    mode='append')
                # deleting json flatten files 
                del_path_key = 'part_flat_data/{}'.format(sub_area)
                delete_s3_file_list(internal_process_bucket, del_path_key)
                print("=======flatten json file deleted=========",del_path_key)

                if get_job_step_active(PII_DATA_MASKING_ID,lst_job_step_config) and valid_data_cnt > 0:
                    print('===== Data masking started ====== ')
                    array_fields = []
                    #valid_df2.printSchema()
                    for coln in valid_df2.dtypes:
                        if coln[1].startswith('array'):
                            array_fields.append(coln[0])
                    extended_array_fields = ['UUID']
                    
                    key = "{}/PIIScalarFields.json".format(base_path)
                    content = read_input_config(config_bucket_name,key)
                    if sub_area == 'ZESTY' or sub_area.upper() == 'TNEDICCA':
                        pii_scalar_fields = content[sub_area.upper()]
                        print("pii_scalar_fields: \n"+",".join(pii_scalar_fields))
                        extended_array_fields.extend(array_fields)
                        print('extended_array_fields : {}'.format(extended_array_fields))
                    
                        valid_df3 = valid_df2.withColumn('UUID',monotonically_increasing_id())
                        extended_array_fields_schema = valid_df3.select(extended_array_fields).schema
                        nested_struct_dict = [row.asDict(recursive=True) for row in valid_df3.select(extended_array_fields).collect()]
                        for coln in pii_scalar_fields:
                            if coln in valid_df3.columns:     
                                if valid_df3.select(coln).dtypes[0][1] == 'string':
                                    valid_df3 = valid_df3.withColumn(coln,lit('XXXX'))
                                elif (valid_df3.select(coln).dtypes[0][1] == 'bigint' or valid_df3.select(coln).dtypes[0][1] == 'int'
                                        or valid_df3.select(coln).dtypes[0][1]=='long'):
                                    valid_df3 = valid_df3.withColumn(coln,lit('999').cast("Integer"))
                        if len(nested_struct_dict)>0:
                            masked_nested_data = mask_data_zesty(nested_struct_dict)
                    else:
                        print('Invalid subject are :{}'.format(sub_area)) 
                    nested_fields_df = spark.createDataFrame(masked_nested_data,extended_array_fields_schema)
                 #   nested_fields_df.select(new_pii_list).show()
                    scalar_field_df = valid_df3.drop(*array_fields)
                    combined_df = scalar_field_df.join(nested_fields_df, on =['UUID']).drop(*['UUID'])
#                     if sub_area in ["ZESTY","CARFAX"]:
#                         #scalar_field_df1 = scalar_field_df.drop(*new_pii_list)
#                         combined_df = scalar_field_df.join(nested_fields_df, on =['UUID']).drop(*['UUID'])
#                     else:
#                         combined_df = scalar_field_df.join(nested_fields_df, on =['UUID']).drop(*['UUID'])
                    print("============data masking completed=========")
                    
                    #data masking and writing to internal datalake bucket
                else:
                    combined_df = valid_df2
                write_to_datalake(MOVE_VALID_TO_DL_STEP_ID,combined_df,dict_file_metadata,internal_datalake_bucket,
                                    mode='append')

                if get_job_step_active(REPAIR_ATHENA_TABLE_STEP_ID,lst_job_step_config) and partition_col.strip()!="" and valid_data_cnt>0 and prev_fail_step_id<=REPAIR_ATHENA_TABLE_STEP_ID:
                    print("Repair Table")
                    repair_table(REPAIR_ATHENA_TABLE_STEP_ID,confidential_db_name) 
                                 
                if get_job_step_active(REPAIR_ATHENA_TABLE_STEP_ID,lst_job_step_config) and partition_col.strip()!="" and valid_data_cnt>0 and prev_fail_step_id<=REPAIR_ATHENA_TABLE_STEP_ID:
                    print("Repair Table")
                    repair_table(REPAIR_ATHENA_TABLE_STEP_ID,internal_db_name)                         
                    #Archive processed data 
                if len(unprocessed_files) > 0:
                    print("count_valiadted_file_list",count_valiadted_file_list)
                    for valid_file in count_valiadted_file_list:
                        ctrl_file_name=valid_file.replace('dat.gz','ctrl') 
                        print("ctrl_file_name",ctrl_file_name)
                        print("data_file_name",valid_file)
                        move_files_to_archive(MOVE_TO_ARC_STEP_ID,bucket_name,valid_file,ctrl_file_name)
                job_status="SUCCESS" 
                if total_record_count < valid_data_cnt:
                    total_record_count = valid_data_cnt
                if total_decrypt_err_rec_count > 0:
                    invalid_data_cnt = invalid_data_cnt+ total_decrypt_err_rec_count                
                message="Spark job completed successfully. \nTotal Records: {}\nValid Records: {} \n*Valid Records includes extra column records with valid columns data. \nInvalid Records:{}\n*Invalid Records includes Extra column,Datatype mismatch and Decryption error records.".format(total_record_count,valid_data_cnt,invalid_data_cnt)                    
                create_email_details(job_status,message)
                
            else:
                job_status="FAILED"   
                #message="Record Count Validation Failed.. \nCount in Control File: {}\nCount in Data File: {}".format(invalid_ctrl_count,invalid_datafile_count)
                #create_email_details(job_status,message)
            
    except Exception as e:
        print("ERROR occurred in executing spark job.\n" + "Details:" +str(e))
        job_status="FAILED"
        if email_message=="":
            message="ERROR occurred in data processing using spark. For details, check job logs.\n {}".format(str(e)) 
            create_email_details(job_status,message)    
        create_custom_log("ERROR",__name__,"SPARK JOB FAILED \nError Details:{}".format(str(e)))
        traceback.print_exc()

    return job_status


def validate_and_start_processing():
    global data_file_rec_cnt
    global total_record_count 
    global ctl_file_rec_cnt
    global valid_data_cnt
    global invalid_data_cnt
    global unprocessed_files 
    global count_valiadted_file_list 
    global ctrl_file_rec_count_dict
    global datfile_rec_count_dict
    global decrypt_rec_count_dict
    global decrypt_err_rec_count_dict
    global invalid_datafile_count
    global invalid_ctrl_count 
    global key_column
   
    
    count_valiadted_file_list = [] 
    datfile_rec_count_dict = {}
    ctrl_file_rec_count_dict = {}
    decrypt_rec_count_dict  = {}
    decrypt_err_rec_count_dict = {}

    try:
        job_status=""
        step_start_time = str(datetime.now()) 
        ctrl_file_path_list = get_ctrl_files_path(valid_file_list)
        print('ctrl_file_path_list :{}'.format(ctrl_file_path_list)) 
        ctrl_df = create_dataframe('csv',True,ctrl_file_path_list,',',None)
        print('ctrl df ==>')
        ctrl_df.show(truncate=False)
        fitered_ctrl_df = ctrl_df.filter(ctrl_df.Record_Count > 0)
        zero_records_file_df = ctrl_df.filter(ctrl_df.Record_Count == 0)
        valid_ctrl_files = fitered_ctrl_df.select('File_Name').rdd.map(lambda x:x[0]).collect()
        invalid_ctrl_files = zero_records_file_df.select('File_Name').rdd.map(lambda x:x[0]).collect()
        unprocessed_files = get_data_file_list(valid_ctrl_files)
        zero_count_datafiles = get_data_file_list(invalid_ctrl_files)
        print('Unprocessed files after empty file check :{}'.format(unprocessed_files))
        print("zero_count_datafiles :{}".format(zero_count_datafiles))
        fitered_ctrl_df.cache()
        fitered_ctrl_df.count()        
        for data_file in zero_count_datafiles:
            job_status="SKIPPED"
            ctrl_file = data_file.replace('dat.gz','ctrl')           
            prepare_job_audit(job_stage,job_status,0,0,0,0,0,0,0,step_start_time,data_file)
            move_files_to_archive(MOVE_TO_ARC_STEP_ID,bucket_name,data_file,ctrl_file)
            create_custom_log("INFO",__name__,"Control file indicated 0 record in {}".format(ctrl_file))            
        
        if len(zero_count_datafiles)>0:
            job_status="SKIPPED"
            message="Spark job skipped as there are zero records in control file.\nFile Names:\n{}".\
            format("\n".join(filename.replace(".dat.gz",".ctrl") for filename in zero_count_datafiles ))
            create_email_details(job_status,message) 
            send_sns_notification() 
        
        if len(unprocessed_files) == 0:
            job_status="SKIPPED"
            message="Spark job skipped as there are zero records in control file.\nFile Names:\n{}".\
            format("\n".join(filename for filename in unprocessed_files ))
            create_email_details(job_status,message) 
            send_sns_notification()
            create_custom_log("INFO",__name__,"Control file indicated 0 records in  all data file")
        else:
            job_status = process_data(fitered_ctrl_df)
    except Exception as e:
        print("ERROR occurred in executing spark job.\nDetails:".format(str(e)))
        job_status="FAILED"
        if email_message=="":
            message="Error in Validating and Processing the job. \nFor Details , check emr logs." 
            create_email_details(job_status,message)
        create_custom_log("ERROR",__name__,"SPARK JOB FAILED \nDetails:{}".format(str(e)))        
        traceback.print_exc()
    finally:
        if logbucket and logs_de_dir_path and abc_temp_file_path:
            write_jobstep_audit()  
            for data_file in count_valiadted_file_list:
                datafile_rec_cnt = datfile_rec_count_dict[data_file]
                ctrl_file_rec_cnt = ctrl_file_rec_count_dict[data_file]
                decrypt_rec_count= decrypt_rec_count_dict[data_file]
                decrypt_err_rec_count = decrypt_err_rec_count_dict[data_file]
                print("invalid_data_cnt_dict -",invalid_data_cnt_dict)
                spark_err_rec_count=int(invalid_data_cnt_dict[data_file.replace('dat.gz','dat')])
                print("spark_err_rec_count - ",spark_err_rec_count)
                valid_data_count = int(decrypt_rec_count) - spark_err_rec_count
                invalid_data_count = decrypt_err_rec_count + spark_err_rec_count
                if valid_data_count < 0:
                    valid_data_count = 0
                
                prepare_job_audit(job_stage,job_status,datafile_rec_cnt,ctrl_file_rec_cnt,decrypt_rec_count,decrypt_err_rec_count,spark_err_rec_count,\
                                            valid_data_count,invalid_data_count,job_start_time,data_file)
            print('main audit records :{}'.format(lst_job_audit)) 
            write_job_audit_and_abc()             
        else:
            create_custom_log("ERROR",__name__,"Unable to write audit due to error in reading audit paths.") 
        process_prefix=data_file_prefix.replace("landing","process")


def initialize(step_id,job_id, sub_area,dict_benji_path_detl,dict_kms_keys):
    global process_date, bucket_name, data_file_prefix, file_name_prefix, data_file_name, control_file_name,\
    sourcefileFormat,sparkFileFormat,outputFileFormat, header,delimiter,\
    logbucket,partition_col,partition_by_fmt, partition_range_val, full_qualified_control_file_name,\
    schema_dir_path,archive_file_path,abc_temp_file_path,abc_file_path,\
    datalake_prefix_path,logs_de_dir_path,error_temp_file_path,error_file_path ,ddl_dir_path,\
    schema_dir_path_for_ddl,schema_arc_dir_path_for_ddl, \
    lst_error_detl , dict_audit_col_detls, dict_tmsp_mapping_detl,\
    lst_job_step_config,internal_db_name,confidential_db_name,\
    DATA_KMS_KEY,PROC_KMS_KEY,CNF_LOG_KMS_KEY,count_valiadted_file_list,rootTag,rowTag,\
    internal_datalake_bucket,confidential_datalake_bucket,internal_process_bucket,hdfs_validated_files_path
    
    global lst_job_audit 
    lst_job_audit = []
    
    step_desc="Read Config Files from Lambda and S3 File Path"       
    try:
        create_custom_log("INFO",__name__,"Read Config Files from Lambda and S3 File Path is started")
        dict_common_path_detl, lst_error_detl,dict_audit_col_detls = get_common_configs()
        
        step_start_time                 = str(datetime.now())
        bucket_name,data_file_prefix    = get_bucket_name(full_qualified_data_file_name)
        DePrefix                        = dict_common_path_detl.get("PrefixDetails").get("ConfigPrefix").get("DePrefix")
        job_conf_base_path              = "{}/{}".format(DePrefix,sub_area)
        dict_job_map_config             = get_job_configs(job_conf_base_path,'JobMapConfig')    
        dict_job_config                 = dict_job_map_config.get("JobConfig")     
        file_name_prefix                = dict_job_config.get("FileNamePrefix")  
        data_file_name                  = full_qualified_data_file_name.split("/")[-1]
        logbucket                       = dict_common_path_detl.get("BucketName").get("LogsBucket")      
        dict_job_config                 = dict_job_map_config.get("JobConfig")
        lst_job_step_config             = dict_job_map_config.get("JobStepConfig")  
        partition_col                   = dict_job_config.get("PartitionColumn")
        partition_by_fmt                = dict_job_config.get("PartitionByFormat")
        partition_range_val             = int(dict_job_config.get("PartitionRangeValue")) if partition_by_fmt=="range" else 0
        sourcefileFormat                = dict_job_config.get("SourceFileFormat")
        sparkFileFormat                 = dict_job_config.get("SparkFileFormat")
        outputFileFormat                = dict_job_config.get("OutputFileFormat")
        delimiter                       = dict_job_config.get("Delimiter")       
        confidential_db_name            = dict_common_path_detl.get("ConfidentialDBName")
        internal_db_name                = dict_common_path_detl.get("InternalDBName")        
        rootTag                         = dict_job_config.get("RootTag")
        rowTag                          = dict_job_config.get("RowTag") 
        confidential_datalake_bucket    = dict_common_path_detl.get("BucketName").get("ConfidentialBucket")
        internal_datalake_bucket        = dict_common_path_detl.get("BucketName").get("InternalBucket")  
        internal_process_bucket         = dict_common_path_detl.get("BucketName").get("InternalProcesBucket")
        
        print("confidential_datalake_bucket :{}".format(confidential_datalake_bucket))
        print("internal_datalake_bucket  :{}".format(internal_datalake_bucket))
        print("internal_process_bucket :{}".format(internal_process_bucket))
        print("dict_job_config :{}".format(dict_job_config))
        
        print("rootTag : {} , RowTag :{}".format(rootTag,rowTag))

        if dict_job_config.get("Header") == "true":
            header = True 
        else:
            header = False
 
        schema_dir_path                     = dict_benji_path_detl.get("Schema_Dir_Path")
        full_qualified_control_file_name    = "{}.ctrl".format(full_qualified_data_file_name.split(".")[0])
        archive_file_path                   = dict_benji_path_detl.get("Process_Arc_Dir_Path")
        abc_temp_file_path                  = dict_benji_path_detl.get("Process_Temp_ABC_Dir_Path")   
        abc_file_path                       = dict_benji_path_detl.get("Process_ABC_Dir_Path")           
        datalake_prefix_path                = dict_benji_path_detl.get("Datalake_Data_Dir_Path")
        logs_de_dir_path                    = dict_benji_path_detl.get("Logs_DE_Dir_Path")    
        error_temp_file_path                = dict_benji_path_detl.get("Process_Temp_Err_Dir_Path")
        error_file_path                     = dict_benji_path_detl.get("Process_Err_Dir_Path")
        ddl_dir_path                        = dict_benji_path_detl.get("DDL_Dir_Path")
        schema_dir_path_for_ddl             = dict_benji_path_detl.get("Schema_Dir_Path_FOR_DDL")
        schema_arc_dir_path_for_ddl         = dict_benji_path_detl.get("Schema_Arc_Dir_Path")
        DATA_KMS_KEY                        = dict_kms_keys.get("datalake_kms_key")
        PROC_KMS_KEY                        = dict_kms_keys.get("process_kms_key")
        CNF_LOG_KMS_KEY                     = dict_kms_keys.get("logs_kms_key")
                
        step_status = "SUCCESS"
        error_message = None
    except Exception as e:
        step_status     = "FAILED"
        error_message   = get_error_message(READ_CONFIG_ERR_ID)
        email_message   = error_message
        create_custom_log("ERROR",__name__,"{}\nDetails:{}".format(error_message,str(e)))
        raise Exception("Exception in Record Count Validation process."+str(e))
    finally:
        step_end_time = str(datetime.now())
        prepare_jobstep_audit(step_id,step_desc, \
                                    step_start_time,step_end_time,step_status,error_message)



# Excecution block
if __name__ == "__main__":

    args                             =          sys.argv
    environment                      =          args[1]
    job_id                           =          args[2]
    job_name                         =          args[3]
    job_key                          =          args[4]
    config_bucket_name               =          args[5]
    base_path                        =          args[6]
    confidential_process_bucket      =          args[7]    
    source_name                      =          args[8]
    sub_area                         =          args[9]
    size_limit                       =          int(args[10])
    full_qualified_data_file_name    =          args[11]
    data_file_hdfs_path              =          args[12]
    list_of_valid_file               =          args[13]
    str_kms_keys                     =          args[14]
    str_benji_path_detl              =          args[15]    
    sns_topic_arn                    =          args[16]
    process_date                     =          args[17]


    valid_file_list = json.loads(list_of_valid_file)
   # valid_file_list = list_of_valid_file.split(" ")
    
    # Audit details 
    lst_job_step_audit               =       []
    lst_error_detl                   =       []
    dict_audit_col_detls             =       {}
    
    # StepID allocation 
    READ_CONFIG_STEP_ID             =           4
    ALREADY_PROC_STEP_ID            =           5
    PREV_FAIL_CHECK_STEP_ID         =           6
    COPY_TO_PROC_STEP_ID            =           7
    UNZIP_FILE_STEP_ID              =           8
    CREATE_DF_STEP_ID               =           9    
    GET_METADATA_STEP_ID            =           10
    GET_RULES_STEP_ID               =           11
    REC_CNT_VAL_STEP_ID             =           12
    SCHEMA_VAL_STEP_ID              =           13
    NOT_NULL_VAL_STEP_ID            =           14
    DATATYPE_VAL_STEP_ID            =           15
    DATE_FORMAT_VAL_STEP_ID         =           16
    TS_FORMAT_VAL_STEP_ID           =           17
    GET_VAL_INVAL_DF_STEP_ID        =           18
    TYPECAST_DF_STEP_ID             =           19
    MOVE_VALID_TO_DL_STEP_ID        =           20
    MOVE_INVALID_TO_DL_STEP_ID      =           21
    REPAIR_ATHENA_TABLE_STEP_ID     =           22
    SCHEMA_EVOL_CHECK_STEP_ID       =           23
    PII_DATA_MASKING_ID             =           24
    MOVE_TO_ARC_STEP_ID             =           25


    #Error ID allocation 
    PATH_NOT_FOUND_ERR_ID           =           21
    READ_CONFIG_ERR_ID              =           22
    ALREADY_PROC_ERR_ID             =           23
    ERR_WR_FAIL_CHK_ERR_ID          =           24
    ARC_FAIL_CHECK_ERR_ID           =           25
    COPY_TO_PROC_ERR_ID             =           26
    UNZIP_FILE_ERR_ID               =           27
    REC_CNT_VAL_ERR_ID              =           28
    READ_METADATA_ERR_ID            =           29
    SCHEMA_VAL_ERR_ID               =           30
    NOT_NULL_VAL_ERR_ID             =           31
    DATATYPE_VAL_ERR_ID             =           32
    DATE_FORMAT_VAL_ERR_ID          =           33
    TS_FORMAT_VAL_ERR_ID            =           34
    GET_VAL_INVAL_DF_ERR_ID         =           35
    TYPECAST_DF_ERR_ID              =           36
    MOVE_VALID_TO_DL_ERR_ID         =           37
    MOVE_INVALID_TO_DL_ERR_ID       =           38
    MOVE_TO_ARC_ERR_ID              =           39
    SCHEMA_EVOL_CHECK_ERR_ID        =           40
    CREATE_DF_ERR_ID                =           41
    REPAIR_TABLE_ERR_ID             =           42
    REC_CNT_VAL_EXP_ERR_ID          =           43
    SCHEMA_VAL_EXP_ERR_ID           =           44
    VAL_RULE_ERR_ID                 =           45

    #Job Audit attributes 
    job_stage               =           "SPARK"
    logbucket               =            ""
    logs_de_dir_path        =            ""
    abc_file_path           =            ""        
    job_start_time          =            str(datetime.now())
    data_file_rec_cnt       =            0
    ctl_file_rec_cnt        =            0
    valid_data_cnt          =            0
    invalid_data_cnt        =            0
    email_subject           =            ""
    email_message           =            ""
    
    try:        
        create_custom_log("INFO",__name__,"********** SPARK JOB STARTED **********")
        create_custom_log("INFO",__name__,"Arguments received from lambda : \n{}".format(args))                
        dict_benji_path_detl=json.loads(str_benji_path_detl)
        dict_kms_keys=json.loads(str_kms_keys)
        initialize(READ_CONFIG_STEP_ID,job_id, sub_area,dict_benji_path_detl,dict_kms_keys)
        create_spark_session()
        validate_and_start_processing()  
    except Exception as e:
        job_status="FAILED"
        create_custom_log("ERROR",__name__,"Exception in Spark Job.\nError Details:{}".format(str(e)))
        traceback.print_exc()
        message="Spark job failed due to following Exceptions. \n{}\nFor Details , check emr logs.".format(str(e))
        create_email_details(job_status,message) if email_message=="" else None
    finally:    
        send_sns_notification()    
        create_custom_log("INFO",__name__,"********** SPARK JOB FINISHED **********")   
